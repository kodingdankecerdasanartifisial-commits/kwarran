

<?php $__env->startSection('page_title', 'Manajemen LPK - Agenda Kegiatan'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-white">
        <h5 class="m-0 fw-bold">Agenda Kegiatan LPK</h5>
    </div>
    <div class="card-body text-center py-5">
        <i class="fas fa-calendar-alt fa-4x text-muted mb-3"></i>
        <h4>Halaman Sedang Dalam Pengembangan</h4>
        <p class="text-muted">Fitur untuk mengelola agenda kegiatan khusus LPK akan segera hadir.</p>
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-primary">Kembali ke Dashboard</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/admin/lpk/agendas.blade.php ENDPATH**/ ?>