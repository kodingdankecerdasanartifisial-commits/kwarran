<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hasil Statistik: <?php echo e($form->title); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { background-color: #f8f9fa; }
        .hero-section { 
            background: linear-gradient(135deg, #4B2C20 0%, #8d5540 100%); 
            color: white; 
            padding: 60px 0; 
            margin-bottom: 40px;
            border-bottom: 5px solid #F2C94C;
        }
        .chart-card { background: white; border-radius: 15px; border: none; box-shadow: 0 10px 30px rgba(0,0,0,0.05); transition: transform 0.3s; }
        .chart-card:hover { transform: translateY(-5px); }
        .footer-text { margin-top: 50px; padding: 20px; text-align: center; color: #666; font-size: 0.9rem; }
    </style>
</head>
<body>
    <div class="hero-section text-center">
        <div class="container">
            <h1 class="fw-bold mb-3"><?php echo e($form->title); ?></h1>
            <p class="lead opacity-75 mb-0"><?php echo e($form->description); ?></p>
            <div class="mt-4">
                <span class="badge bg-warning text-dark px-3 py-2 rounded-pill shadow-sm">
                    <i class="fas fa-layer-group me-2"></i>Kategori: <?php echo e($form->category); ?>

                </span>
                <span class="badge bg-light text-dark px-3 py-2 rounded-pill shadow-sm ms-2">
                    <i class="fas fa-database me-2"></i><?php echo e($form->entries->count()); ?> Laporan Masuk
                </span>
            </div>
        </div>
    </div>

    <div class="container">
        <?php if($chartData): ?>
            <div class="row g-4">
                <?php $__currentLoopData = $chartData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 mb-4">
                    <div class="card chart-card h-100">
                        <div class="card-body p-4 text-center">
                            <h5 class="fw-bold border-bottom pb-3 mb-4 text-start"><?php echo e($data['label']); ?></h5>
                            <div style="position: relative; height: 300px;">
                                <canvas id="chart_<?php echo e($data['id']); ?>"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-chart-area fa-4x text-muted mb-3"></i>
                <h3>Belum ada data untuk ditampilkan</h3>
                <p class="text-muted">Visualisasi grafik akan muncul setelah operator mengisi data.</p>
            </div>
        <?php endif; ?>

        <div class="footer-text">
            <hr class="mb-4">
            <p>&copy; 2026 Kwarran Bekasi Timur. All Rights Reserved.</p>
            <p>Sistem Informasi Statistik Kwarran (SISRAN)</p>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            <?php $__currentLoopData = $chartData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            const ctx_<?php echo e($data['id']); ?> = document.getElementById('chart_<?php echo e($data['id']); ?>').getContext('2d');
            new Chart(ctx_<?php echo e($data['id']); ?>, {
                type: '<?php echo e($data['chart_type']); ?>',
                data: {
                    labels: <?php echo json_encode($data['labels']); ?>,
                    datasets: [{
                        label: '<?php echo e($data['label']); ?>',
                        data: <?php echo json_encode($data['values']); ?>,
                        backgroundColor: [
                            'rgba(75, 44, 32, 0.7)',
                            'rgba(242, 201, 76, 0.7)',
                            'rgba(54, 162, 235, 0.7)',
                            'rgba(255, 99, 132, 0.7)',
                            'rgba(153, 102, 255, 0.7)',
                            'rgba(255, 159, 64, 0.7)'
                        ],
                        borderColor: 'rgba(75, 44, 32, 1)',
                        borderWidth: 1,
                        borderRadius: <?php echo e($data['chart_type'] == 'bar' ? 5 : 0); ?>

                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: <?php echo e(in_array($data['chart_type'], ['pie', 'doughnut']) ? 'true' : 'false'); ?> }
                    },
                    scales: {
                        y: { 
                            beginAtZero: true, 
                            display: <?php echo e(in_array($data['chart_type'], ['pie', 'doughnut']) ? 'false' : 'true'); ?>,
                            grid: { drawBorder: false } 
                        },
                        x: {
                            display: <?php echo e(in_array($data['chart_type'], ['pie', 'doughnut']) ? 'false' : 'true'); ?>

                        }
                    }
                }
            });
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        });
    </script>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\kwarran\resources\views/pages/sisran/result.blade.php ENDPATH**/ ?>