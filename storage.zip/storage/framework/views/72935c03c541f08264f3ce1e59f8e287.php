<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', config('app.name', 'Kwarran Bekasi Timur')); ?></title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?php echo e(asset('logo.png')); ?>">
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    
    <style>

        :root {
            --primary-color: #4B2C20; /* Pramuka Brown */
            --secondary-color: #F2C94C; /* Pramuka Gold */
            --accent-color: #D32F2F; /* Red for accents */
            --light-bg: #f8f9fa;
            --dark-text: #333333;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--light-bg);
            color: var(--dark-text);
        }

        /* Top Bar */
        .top-bar {
            background-color: var(--primary-color);
            color: white;
            padding: 5px 0;
            font-size: 0.85rem;
        }
        .top-bar a {
            color: white;
            text-decoration: none;
            margin-left: 15px;
        }

        /* Header */
        .header {
            background-color: white;
            padding: 20px 0;
            border-bottom: 3px solid var(--secondary-color);
        }
        .logo-text h1 {
            font-size: 1.8rem;
            font-weight: 700;
            margin: 0;
            color: var(--primary-color);
        }
        .logo-text p {
            margin: 0;
            font-size: 1rem;
            color: #666;
        }

        /* Navbar */
        .navbar {
            background-color: var(--primary-color) !important;
            padding: 0;
        }
        .navbar-nav .nav-link {
            color: white !important;
            padding: 15px 12px !important;
            font-weight: 500;
            text-transform: uppercase;
            font-size: 0.82rem;
        }
        .navbar-nav .nav-link:hover {
            background-color: var(--secondary-color);
            color: var(--primary-color) !important;
        }

        /* Hero Section */
        .hero {
            background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('https://images.unsplash.com/photo-1526772662000-3f88f10405ff?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 100px 0;
            text-align: center;
            margin-bottom: 50px;
        }
        .hero h1 {
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 20px;
        }

        /* Posts */
        .post-card {
            border: none;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s;
            border-radius: 10px;
            overflow: hidden;
        }
        .post-card:hover {
            transform: translateY(-5px);
        }
        .post-category {
            background-color: var(--secondary-color);
            color: var(--primary-color);
            padding: 3px 10px;
            border-radius: 5px;
            font-size: 0.75rem;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
            margin-bottom: 10px;
        }
        .featured-image {
            height: 200px;
            object-fit: cover;
            width: 100%;
        }

        /* Footer */
        .footer {
            background-color: var(--primary-color);
            color: white;
            padding: 60px 0 20px;
            margin-top: 80px;
        }
        .footer h5 {
            color: var(--secondary-color);
            margin-bottom: 25px;
            font-weight: 600;
        }
        .footer-links ul {
            list-style: none;
            padding: 0;
        }
        .footer-links ul li {
            margin-bottom: 10px;
        }
        .footer-links ul li a {
            color: #ddd;
            text-decoration: none;
            transition: color 0.3s;
        }
        .footer-links ul li a:hover {
            color: var(--secondary-color);
        }
        .footer-bottom {
            text-align: center;
        }
        /* Sidebar */
        .sidebar-widget {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 30px;
            border-left: 4px solid var(--secondary-color);
        }
        .sidebar-widget h5 {
            color: var(--primary-color);
            font-weight: 700;
            margin-bottom: 20px;
            text-transform: uppercase;
            font-size: 1rem;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }
        .category-list a {
            display: block;
            padding: 8px 0;
            color: #555;
            text-decoration: none;
            transition: color 0.3s;
            border-bottom: 1px solid #f9f9f9;
        }
        .category-list a:hover {
            color: var(--primary-color);
            padding-left: 5px;
        }
        .category-list a i {
            margin-right: 8px;
            color: var(--secondary-color);
        }
        /* Sidebar behavior for two-column layout */
        .layout-sidebar { padding-left: 0; }
        @media (min-width: 992px) {
            .layout-main { width: 100%; }
        }
        /* Auto-resize images in sidebar widgets */
        .widget-content-html img {
            width: 100%;
            height: auto;
            display: block; /* Ensure no extra space below images */
        }

        /* Mega Menu Styles */
        .mega-dropdown {
            position: static !important;
        }
        .mega-menu {
            left: 0;
            right: 0;
            width: 100%;
            padding: 30px;
            border-radius: 0;
            margin-top: 0;
            border-top: 5px solid var(--secondary-color);
            background: #fff;
            box-shadow: 0 15px 30px rgba(0,0,0,0.1);
        }
        .mega-menu h6 {
            font-size: 0.9rem;
            letter-spacing: 1px;
            padding-bottom: 10px;
            border-bottom: 2px solid #eee;
        }
        .mega-menu a {
            font-size: 0.95rem;
            transition: color 0.2s;
        }
        .mega-menu a:hover {
            color: var(--primary-color) !important;
            padding-left: 5px;
        }

        /* Perbaikan untuk Mobile */
        @media (max-width: 991.98px) {
            .navbar-collapse {
                background-color: var(--primary-color);
                padding: 15px;
                border-bottom: 3px solid var(--secondary-color);
            }
            
            .footer {
                padding: 40px 20px;
                margin-top: 40px;
            }

            .footer-bottom {
                padding-bottom: 100px !important; /* Ruang ekstra signifikan agar terlihat di mobile browser */
            }

            .footer-bottom p, .footer-bottom a {
                color: #ffffff !important; /* Warna putih solid agar terbaca jelas */
            }
        }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
    <!-- Top Bar -->
    <div class="top-bar d-none d-lg-block">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <i class="far fa-calendar-alt me-2"></i> <?php echo e(now()->translatedFormat('l, d F Y')); ?>

                </div>
                <div class="col-md-6 text-end">
                    <?php if($fb = \App\Models\Setting::get('social_facebook')): ?> <a href="<?php echo e($fb); ?>" target="_blank"><i class="fab fa-facebook-f"></i></a> <?php endif; ?>
                    <?php if($ig = \App\Models\Setting::get('social_instagram')): ?> <a href="<?php echo e($ig); ?>" target="_blank"><i class="fab fa-instagram"></i></a> <?php endif; ?>
                    <?php if($yt = \App\Models\Setting::get('social_youtube')): ?> <a href="<?php echo e($yt); ?>" target="_blank"><i class="fab fa-youtube"></i></a> <?php endif; ?>
                    <?php if($x = \App\Models\Setting::get('social_x')): ?> <a href="<?php echo e($x); ?>" target="_blank"><i class="fa-brands fa-x-twitter"></i></a> <?php endif; ?>
                    <?php if($tt = \App\Models\Setting::get('social_tiktok')): ?> <a href="<?php echo e($tt); ?>" target="_blank"><i class="fab fa-tiktok"></i></a> <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8 d-flex align-items-center">
                    <img src="<?php echo e(asset('logo.png')); ?>" alt="Logo" height="70" class="me-3">
                    <div class="logo-text">
                        <h1>KWARTIR RANTING BEKASI TIMUR</h1>
                        <p>Gerakan Pramuka Kota Bekasi</p>
                    </div>
                </div>
                <div class="col-md-4 text-end d-none d-md-block">
                    <!-- Search Bar or something -->
                </div>
            </div>
        </div>
    </header>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
        <div class="container">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav w-100 justify-content-between">
                    
                    <li class="nav-item d-lg-none py-3 border-bottom border-white border-opacity-25">
                        <form action="<?php echo e(route('posts.index')); ?>" method="GET" class="d-flex px-2">
                            <input class="form-control form-control-sm rounded-start-pill border-0" type="search" name="search" placeholder="Cari Berita..." aria-label="Search">
                            <button class="btn btn-warning btn-sm rounded-end-pill px-3" type="submit"><i class="fas fa-search"></i></button>
                        </form>
                    </li>
                    
                    <?php $__empty_1 = true; $__currentLoopData = $publicMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $isBerita = (str_contains(strtolower($menu->name), 'berita') || str_contains($menu->url, 'berita')) && !str_contains($menu->url, 'kirim-berita');
                            $isMateri = str_contains(strtolower($menu->name), 'materi');
                        ?>
                        
                        <?php if($isMateri): ?>
                            
                            
                             <li class="nav-item dropdown mega-dropdown">
                                <a class="nav-link dropdown-toggle <?php echo e(request()->is('materi*') ? 'active' : ''); ?>" href="#" id="navbarDropdownMateriDB" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <?php echo e($menu->name); ?>

                                </a>
                                <div class="dropdown-menu mega-menu" aria-labelledby="navbarDropdownMateriDB">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <h6 class="text-uppercase fw-bold text-primary mb-3">Materi Belajar</h6>
                                                <ul class="list-unstyled">
                                                    <?php $__currentLoopData = \App\Models\Category::where('name', 'like', 'Materi%')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="mb-2"><a href="<?php echo e(route('categories.show', $cat->slug)); ?>" class="text-decoration-none text-dark hover-primary"><?php echo e($cat->name); ?></a></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                            <div class="col-md-8">
                                                <h6 class="text-uppercase fw-bold text-primary mb-3">Materi Terbaru</h6>
                                                <div class="row">
                                                    <?php $__currentLoopData = \App\Models\Post::whereHas('category', function($q){ $q->where('name', 'like', 'Materi%'); })->latest()->take(2)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-6">
                                                        <div class="card border-0 shadow-sm h-100">
                                                            <?php if($latest->featured_image): ?>
                                                                <img src="<?php echo e(asset('storage/' . $latest->featured_image)); ?>" class="card-img-top" alt="<?php echo e($latest->title); ?>" style="height: 120px; object-fit: cover;">
                                                            <?php elseif($latest->youtube_url): ?>
                                                                <?php
                                                                    preg_match('/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/', $latest->youtube_url, $matches);
                                                                    $thumb = isset($matches[1]) ? "https://img.youtube.com/vi/{$matches[1]}/mqdefault.jpg" : null;
                                                                ?>
                                                                <?php if($thumb): ?>
                                                                    <img src="<?php echo e($thumb); ?>" class="card-img-top" alt="<?php echo e($latest->title); ?>" style="height: 120px; object-fit: cover;">
                                                                    <div class="position-absolute top-50 start-50 translate-middle"><i class="fab fa-youtube text-danger fa-2x bg-white rounded-circle p-1"></i></div>
                                                                <?php else: ?>
                                                                    <div class="bg-light d-flex align-items-center justify-content-center" style="height: 120px;"><i class="fas fa-image text-muted"></i></div>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <div class="bg-light d-flex align-items-center justify-content-center" style="height: 120px;"><i class="fas fa-file-pdf text-danger fa-2x"></i></div>
                                                            <?php endif; ?>
                                                            <div class="card-body p-2">
                                                                <h6 class="card-title small fw-bold mb-0">
                                                                    <a href="<?php echo e(route('posts.show', $latest->slug)); ?>" class="text-decoration-none text-dark stretched-link"><?php echo e(Str::limit($latest->title, 50)); ?></a>
                                                                </h6>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>

                        <?php elseif($isBerita): ?>
                            
                            <li class="nav-item dropdown mega-dropdown">
                                <a class="nav-link dropdown-toggle <?php echo e(request()->is('berita*') || request()->is('posts*') ? 'active' : ''); ?>" href="<?php echo e(url($menu->url)); ?>" id="navbarDropdown<?php echo e($menu->id); ?>" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <?php echo e($menu->name); ?>

                                </a>
                                <div class="dropdown-menu mega-menu" aria-labelledby="navbarDropdown<?php echo e($menu->id); ?>">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <h6 class="text-uppercase fw-bold text-primary mb-3">Kategori Berita</h6>
                                                <ul class="list-unstyled">
                                                    <?php $__currentLoopData = \App\Models\Category::where('name', 'not like', 'Materi%')->take(6)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="mb-2"><a href="<?php echo e(route('categories.show', $cat->slug)); ?>" class="text-decoration-none text-dark hover-primary"><?php echo e($cat->name); ?></a></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="mt-3"><a href="<?php echo e(route('posts.index')); ?>" class="btn btn-sm btn-outline-warning rounded-pill">Lihat Semua Berita</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-md-8">
                                                <h6 class="text-uppercase fw-bold text-primary mb-3">Berita Terbaru</h6>
                                                <div class="row">
                                                    <?php $__currentLoopData = \App\Models\Post::whereHas('category', function($q){ $q->where('name', 'not like', 'Materi%'); })->latest()->take(2)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-6">
                                                        <div class="card border-0 shadow-sm h-100">
                                                            <?php if($latest->featured_image): ?>
                                                                <img src="<?php echo e(asset('storage/' . $latest->featured_image)); ?>" class="card-img-top" alt="<?php echo e($latest->title); ?>" style="height: 120px; object-fit: cover;">
                                                            <?php elseif($latest->youtube_url): ?>
                                                                <?php
                                                                    preg_match('/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/', $latest->youtube_url, $matches);
                                                                    $thumb = isset($matches[1]) ? "https://img.youtube.com/vi/{$matches[1]}/mqdefault.jpg" : null;
                                                                ?>
                                                                <?php if($thumb): ?>
                                                                    <img src="<?php echo e($thumb); ?>" class="card-img-top" alt="<?php echo e($latest->title); ?>" style="height: 120px; object-fit: cover;">
                                                                <?php else: ?>
                                                                    <div class="bg-light d-flex align-items-center justify-content-center" style="height: 120px;"><i class="fas fa-image text-muted"></i></div>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <div class="bg-light d-flex align-items-center justify-content-center" style="height: 120px;"><i class="fas fa-image text-muted"></i></div>
                                                            <?php endif; ?>
                                                            <div class="card-body p-2">
                                                                <h6 class="card-title small fw-bold mb-0">
                                                                    <a href="<?php echo e(route('posts.show', $latest->slug)); ?>" class="text-decoration-none text-dark stretched-link"><?php echo e(Str::limit($latest->title, 50)); ?></a>
                                                                </h6>
                                                                <small class="text-muted" style="font-size: 0.7rem;"><?php echo e($latest->published_at?->diffForHumans()); ?></small>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            
                            

                        <?php elseif($menu->children->count() > 0): ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown<?php echo e($menu->id); ?>" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <?php echo e($menu->name); ?>

                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown<?php echo e($menu->id); ?>">
                                    <?php $__currentLoopData = $menu->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a class="dropdown-item" href="<?php echo e(url($child->url)); ?>"><?php echo e($child->name); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->is(ltrim($menu->url, '/')) || request()->fullUrlIs(url($menu->url)) ? 'active' : ''); ?>" href="<?php echo e(url($menu->url)); ?>"><?php echo e($menu->name); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">Beranda</a></li>
                        
                        <!-- Berita Mega Menu Fallback -->
                        <li class="nav-item dropdown mega-dropdown">
                            <a class="nav-link dropdown-toggle <?php echo e(request()->routeIs('posts*') ? 'active' : ''); ?>" href="<?php echo e(route('posts.index')); ?>" id="navbarDropdownNews" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Berita
                            </a>
                            <div class="dropdown-menu mega-menu shadow border-0 mt-0" aria-labelledby="navbarDropdownNews">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <h6 class="text-uppercase fw-bold text-primary mb-3 text-start">Kategori Berita</h6>
                                            <ul class="list-unstyled text-start">
                                                <?php $__currentLoopData = \App\Models\Category::where('name', 'not like', 'Materi%')->take(6)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="mb-2"><a href="<?php echo e(route('categories.show', $cat->slug)); ?>" class="text-decoration-none text-dark hover-primary"><?php echo e($cat->name); ?></a></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <li class="mt-3"><a href="<?php echo e(route('posts.index')); ?>" class="btn btn-sm btn-outline-warning rounded-pill">Lihat Semua Berita</a></li>
                                            </ul>
                                        </div>
                                        <div class="col-md-8">
                                            <h6 class="text-uppercase fw-bold text-primary mb-3 text-start">Berita Terbaru</h6>
                                            <div class="row">
                                                <?php $__currentLoopData = \App\Models\Post::whereHas('category', function($q){ $q->where('name', 'not like', 'Materi%'); })->latest()->take(2)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-6">
                                                    <div class="card border-0 shadow-sm h-100">
                                                        <?php if($latest->featured_image): ?>
                                                            <img src="<?php echo e(asset('storage/' . $latest->featured_image)); ?>" class="card-img-top" alt="<?php echo e($latest->title); ?>" style="height: 120px; object-fit: cover;">
                                                        <?php elseif($latest->youtube_url): ?>
                                                            <?php
                                                                preg_match('/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/', $latest->youtube_url, $matches);
                                                                $thumb = isset($matches[1]) ? "https://img.youtube.com/vi/{$matches[1]}/mqdefault.jpg" : null;
                                                            ?>
                                                            <?php if($thumb): ?>
                                                                <img src="<?php echo e($thumb); ?>" class="card-img-top" alt="<?php echo e($latest->title); ?>" style="height: 120px; object-fit: cover;">
                                                            <?php else: ?>
                                                                <div class="bg-light d-flex align-items-center justify-content-center" style="height: 120px;"><i class="fas fa-image text-muted"></i></div>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <div class="bg-light d-flex align-items-center justify-content-center" style="height: 120px;"><i class="fas fa-image text-muted"></i></div>
                                                        <?php endif; ?>
                                                        <div class="card-body p-2 text-start">
                                                            <h6 class="card-title small fw-bold mb-0">
                                                                <a href="<?php echo e(route('posts.show', $latest->slug)); ?>" class="text-decoration-none text-dark stretched-link"><?php echo e(Str::limit($latest->title, 50)); ?></a>
                                                            </h6>
                                                            <small class="text-muted" style="font-size: 0.7rem;"><?php echo e($latest->published_at?->diffForHumans()); ?></small>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <!-- Materi Mega Menu Fallback -->
                         <li class="nav-item dropdown mega-dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMateriFallback" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Materi
                            </a>
                            <div class="dropdown-menu mega-menu shadow border-0 mt-0" aria-labelledby="navbarDropdownMateriFallback">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <h6 class="text-uppercase fw-bold text-primary mb-3 text-start">Materi Belajar</h6>
                                            <ul class="list-unstyled text-start">
                                                <?php $__currentLoopData = \App\Models\Category::where('name', 'like', 'Materi%')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="mb-2"><a href="<?php echo e(route('categories.show', $cat->slug)); ?>" class="text-decoration-none text-dark hover-primary"><?php echo e($cat->name); ?></a></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                        <div class="col-md-8">
                                            <h6 class="text-uppercase fw-bold text-primary mb-3 text-start">Materi Terbaru</h6>
                                            <div class="row">
                                                <?php $__currentLoopData = \App\Models\Post::whereHas('category', function($q){ $q->where('name', 'like', 'Materi%'); })->latest()->take(2)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-6">
                                                    <div class="card border-0 shadow-sm h-100">
                                                        <?php if($latest->featured_image): ?>
                                                            <img src="<?php echo e(asset('storage/' . $latest->featured_image)); ?>" class="card-img-top" alt="<?php echo e($latest->title); ?>" style="height: 120px; object-fit: cover;">
                                                        <?php elseif($latest->youtube_url): ?>
                                                            <?php
                                                                preg_match('/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/', $latest->youtube_url, $matches);
                                                                $thumb = isset($matches[1]) ? "https://img.youtube.com/vi/{$matches[1]}/mqdefault.jpg" : null;
                                                            ?>
                                                            <?php if($thumb): ?>
                                                                <img src="<?php echo e($thumb); ?>" class="card-img-top" alt="<?php echo e($latest->title); ?>" style="height: 120px; object-fit: cover;">
                                                                <div class="position-absolute top-50 start-50 translate-middle"><i class="fab fa-youtube text-danger fa-2x bg-white rounded-circle p-1"></i></div>
                                                            <?php else: ?>
                                                                <div class="bg-light d-flex align-items-center justify-content-center" style="height: 120px;"><i class="fas fa-image text-muted"></i></div>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <div class="bg-light d-flex align-items-center justify-content-center" style="height: 120px;"><i class="fas fa-file-pdf text-danger fa-2x"></i></div>
                                                        <?php endif; ?>
                                                        <div class="card-body p-2 text-start">
                                                            <h6 class="card-title small fw-bold mb-0">
                                                                <a href="<?php echo e(route('posts.show', $latest->slug)); ?>" class="text-decoration-none text-dark stretched-link"><?php echo e(Str::limit($latest->title, 50)); ?></a>
                                                            </h6>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('downloads.index')); ?>">Download</a></li>
                        <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('bulletins.*') ? 'active' : ''); ?>" href="<?php echo e(route('bulletins.public')); ?>">Buletin</a></li>
                    <?php endif; ?>
                    
                    
                    <li class="nav-item d-lg-none border-top border-white border-opacity-25 pt-3 mt-2">
                        <div class="d-flex justify-content-center gap-4 py-2">
                            <?php if($fb = \App\Models\Setting::get('social_facebook')): ?> <a href="<?php echo e($fb); ?>" class="text-white fs-5" target="_blank"><i class="fab fa-facebook-f"></i></a> <?php endif; ?>
                            <?php if($ig = \App\Models\Setting::get('social_instagram')): ?> <a href="<?php echo e($ig); ?>" class="text-white fs-5" target="_blank"><i class="fab fa-instagram"></i></a> <?php endif; ?>
                            <?php if($yt = \App\Models\Setting::get('social_youtube')): ?> <a href="<?php echo e($yt); ?>" class="text-white fs-5" target="_blank"><i class="fab fa-youtube"></i></a> <?php endif; ?>
                            <?php if($x = \App\Models\Setting::get('social_x')): ?> <a href="<?php echo e($x); ?>" class="text-white fs-5" target="_blank"><i class="fab fa-x-twitter"></i></a> <?php endif; ?>
                            <?php if($tt = \App\Models\Setting::get('social_tiktok')): ?> <a href="<?php echo e($tt); ?>" class="text-white fs-5" target="_blank"><i class="fab fa-tiktok"></i></a> <?php endif; ?>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main>
        <div class="container my-5">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <h5>Tentang Kwarran</h5>
                    <p><?php echo e(\App\Models\Setting::get('about', 'Kwartir Ranting Gerakan Pramuka Bekasi Timur merupakan satuan organisasi yang mengelola Gerakan Pramuka di tingkat Kecamatan Bekasi Timur.')); ?></p>
                    
                </div>
                <div class="col-lg-2 mb-4">
                    <h5>Tautan Cepat</h5>
                    <div class="footer-links">
                        <ul>
                            <li><a href="<?php echo e(route('home')); ?>">Beranda</a></li>
                            <li><a href="#">Tentang Kami</a></li>
                            <li><a href="<?php echo e(route('posts.index')); ?>">Berita</a></li>
                            <?php if(auth()->guard()->check()): ?>
                            <li><a href="<?php echo e(route('admin.dashboard')); ?>">Panel Admin</a></li>
                            <?php else: ?>
                            <li><a href="<?php echo e(route('login')); ?>">Login Admin</a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 mb-4">
                    <h5>Kategori</h5>
                    <div class="footer-links">
                        <ul>
                            <?php $__currentLoopData = \App\Models\Category::take(4)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('categories.show', $cat->slug)); ?>"><?php echo e($cat->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 mb-4">
                    <h5>Kontak Kami</h5>
                    <p><i class="fas fa-map-marker-alt me-2"></i> <?php echo e(\App\Models\Setting::get('address', 'Kec. Bekasi Timur, Kota Bekasi, Jawa Barat')); ?></p>
                    <p><i class="fas fa-phone me-2"></i> <?php echo e(\App\Models\Setting::get('phone', '+62 ...')); ?></p>
                    <p><i class="fas fa-envelope me-2"></i> <?php echo e(\App\Models\Setting::get('email', 'info@kwarranbekasitimur.id')); ?></p>
                </div>
            </div>
        </div>
        <div class="footer-bottom border-top border-white border-opacity-10 py-5 mt-4">
            <div class="container text-center">
                
                <div class="d-flex justify-content-center gap-3 mb-4">
                    <?php if($fb = \App\Models\Setting::get('social_facebook')): ?> <a href="<?php echo e($fb); ?>" class="btn btn-outline-light btn-sm rounded-circle" style="width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;" target="_blank"><i class="fab fa-facebook-f"></i></a> <?php endif; ?>
                    <?php if($ig = \App\Models\Setting::get('social_instagram')): ?> <a href="<?php echo e($ig); ?>" class="btn btn-outline-light btn-sm rounded-circle" style="width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;" target="_blank"><i class="fab fa-instagram"></i></a> <?php endif; ?>
                    <?php if($yt = \App\Models\Setting::get('social_youtube')): ?> <a href="<?php echo e($yt); ?>" class="btn btn-outline-light btn-sm rounded-circle" style="width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;" target="_blank"><i class="fab fa-youtube"></i></a> <?php endif; ?>
                    <?php if($x = \App\Models\Setting::get('social_x')): ?> <a href="<?php echo e($x); ?>" class="btn btn-outline-light btn-sm rounded-circle" style="width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;" target="_blank"><i class="fa-brands fa-x-twitter"></i></a> <?php endif; ?>
                    <?php if($tt = \App\Models\Setting::get('social_tiktok')): ?> <a href="<?php echo e($tt); ?>" class="btn btn-outline-light btn-sm rounded-circle" style="width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;" target="_blank"><i class="fab fa-tiktok"></i></a> <?php endif; ?>
                </div>

                <p class="mb-1 text-white">&copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>. All Rights Reserved.</p>
                <p class="small text-white mb-0">
                    Di buat untuk Kwarran Bekasi Timur Oleh <a href="https://wa.me/6281389510337" target="_blank" style="color: var(--secondary-color); font-weight: bold;" class="text-decoration-none">Kak MD</a>
                </p>
            </div>
        </div>
    </footer>

    <!-- jQuery (Required for Lightbox) -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script>
        const swiper = new Swiper('.main-slider', {
            loop: true,
            autoplay: {
                delay: 5000,
                disableOnInteraction: false,
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            effect: 'fade',
            fadeEffect: {
                crossFade: true
            },
        });
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\kwarran\resources\views/layouts/public.blade.php ENDPATH**/ ?>