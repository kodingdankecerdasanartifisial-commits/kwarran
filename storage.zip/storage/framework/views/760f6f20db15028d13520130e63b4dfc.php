

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Sidebar Widgets</h5>
        <a href="<?php echo e(route('admin.sidebar-widgets.create')); ?>" class="btn btn-sm btn-primary">Tambah Widget</a>
    </div>
    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Judul</th>
                    <th>Tipe</th>
                    <th>Order</th>
                    <th>Aktif</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $widgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($w->name); ?></td>
                    <td><?php echo e($w->title); ?></td>
                    <td><?php echo e($w->type); ?></td>
                    <td><?php echo e($w->order); ?></td>
                    <td><?php echo e($w->is_active ? 'Ya' : 'Tidak'); ?></td>
                    <td class="text-end">
                        <a href="<?php echo e(route('admin.sidebar-widgets.edit', $w)); ?>" class="btn btn-sm btn-secondary">Edit</a>
                        <form action="<?php echo e(route('admin.sidebar-widgets.destroy', $w)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Hapus widget ini?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/admin/sidebar_widgets/index.blade.php ENDPATH**/ ?>