

<?php $__env->startSection('page_title', 'Laporan Keuangan (Arus Kas)'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-md-4">
        <div class="card bg-success text-white">
            <div class="card-body p-4">
                <h6 class="text-uppercase small fw-bold opacity-75">Total Pemasukan</h6>
                <h2 class="fw-bold m-0">Rp <?php echo e(number_format($totalPemasukan)); ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-danger text-white">
            <div class="card-body p-4">
                <h6 class="text-uppercase small fw-bold opacity-75">Total Pengeluaran</h6>
                <h2 class="fw-bold m-0">Rp <?php echo e(number_format($totalPengeluaran)); ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-primary text-white">
            <div class="card-body p-4">
                <h6 class="text-uppercase small fw-bold opacity-75">Saldo Akhir</h6>
                <h2 class="fw-bold m-0">Rp <?php echo e(number_format($saldo)); ?></h2>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="m-0 fw-bold">Riwayat Transaksi</h5>
        <div>
            <a href="<?php echo e(route('admin.finances.calendar')); ?>" class="btn btn-outline-primary btn-sm rounded-pill me-2">
                <i class="fas fa-calendar-alt me-1"></i> Lihat Kalender
            </a>
            <a href="<?php echo e(route('admin.finances.create')); ?>" class="btn btn-primary btn-sm rounded-pill">
                <i class="fas fa-plus me-1"></i> Tambah Transaksi
            </a>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="bg-light">
                    <tr>
                        <th width="5%">#</th>
                        <th>Tanggal</th>
                        <th>Keterangan</th>
                        <th>Jenis</th>
                        <th>Jumlah</th>
                        <th width="15%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $finances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($item->transaction_date)->format('d M Y')); ?></td>
                        <td>
                            <div class="fw-bold"><?php echo e($item->description); ?></div>
                            <?php if($item->details): ?>
                                <small class="text-muted"><?php echo e($item->details); ?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($item->type === 'pemasukan'): ?>
                                <span class="badge bg-success-subtle text-success border border-success border-opacity-25 rounded-pill px-3">Masuk</span>
                            <?php else: ?>
                                <span class="badge bg-danger-subtle text-danger border border-danger border-opacity-25 rounded-pill px-3">Keluar</span>
                            <?php endif; ?>
                        </td>
                        <td class="fw-bold <?php echo e($item->type === 'pemasukan' ? 'text-success' : 'text-danger'); ?>">
                            <?php echo e($item->type === 'pemasukan' ? '+' : '-'); ?> Rp <?php echo e(number_format($item->amount)); ?>

                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.finances.edit', $item->id)); ?>" class="btn btn-sm btn-outline-primary rounded-circle" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <?php if(auth()->user()->role === 'admin'): ?>
                            <form action="<?php echo e(route('admin.finances.destroy', $item->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Hapus data transaksi ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-outline-danger rounded-circle" title="Hapus">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-5 text-muted">Belum ada riwayat transaksi.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="mt-3">
            <?php echo e($finances->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/admin/finances/index.blade.php ENDPATH**/ ?>