

<?php $__env->startSection('page_title', 'Kelola Dokumen (Embed PDF)'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="m-0 fw-bold">Daftar Dokumen</h5>
        <a href="<?php echo e(route('admin.documents.create')); ?>" class="btn btn-primary btn-sm rounded-pill">
            <i class="fas fa-plus me-1"></i> Upload Dokumen PDF
        </a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="bg-light">
                    <tr>
                        <th width="5%">#</th>
                        <th>Judul Dokumen</th>
                        <th>Link Publik</th>
                        <th>Status</th>
                        <th width="15%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td class="fw-bold"><?php echo e($item->title); ?></td>
                        <td>
                            <div class="input-group input-group-sm">
                                <input type="text" class="form-control" value="<?php echo e(route('documents.public.show', $item->slug)); ?>" id="link-<?php echo e($item->id); ?>" readonly>
                                <button class="btn btn-outline-secondary" type="button" onclick="copyLink('link-<?php echo e($item->id); ?>')">
                                    <i class="fas fa-copy"></i>
                                </button>
                            </div>
                        </td>
                        <td>
                            <?php if($item->is_published): ?>
                                <span class="badge bg-success rounded-pill">Publik</span>
                            <?php else: ?>
                                <span class="badge bg-secondary rounded-pill">Draft</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group">
                                <a href="<?php echo e(route('documents.public.show', $item->slug)); ?>" target="_blank" class="btn btn-sm btn-outline-info">
                                    <i class="fas fa-external-link-alt"></i>
                                </a>
                                <a href="<?php echo e(route('admin.documents.edit', $item->id)); ?>" class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <?php if(auth()->user()->role === 'admin'): ?>
                                <form action="<?php echo e(route('admin.documents.destroy', $item->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Hapus dokumen ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-outline-danger">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center py-5 text-muted">Belum ada dokumen PDF yang diupload.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="mt-3">
            <?php echo e($documents->links()); ?>

        </div>
    </div>
</div>

<script>
function copyLink(id) {
    var copyText = document.getElementById(id);
    copyText.select();
    copyText.setSelectionRange(0, 99999);
    navigator.clipboard.writeText(copyText.value);
    alert("Link berhasil disalin!");
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/admin/documents/index.blade.php ENDPATH**/ ?>