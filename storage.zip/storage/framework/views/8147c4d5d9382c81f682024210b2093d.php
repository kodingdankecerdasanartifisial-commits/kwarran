

<?php $__env->startSection('page_title', 'Kelola Gudep / Pangkalan'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="m-0 fw-bold">Daftar Gudep / Pangkalan</h5>
        <a href="<?php echo e(route('admin.gudep.create')); ?>" class="btn btn-primary btn-sm rounded-pill"><i class="fas fa-plus me-1"></i> Tambah Gudep</a>
    </div>
    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th width="50">No</th>
                        <th width="80">Logo</th>
                        <th>Nama Gudep</th>
                        <th>Anggota</th>
                        <th>Status</th>
                        <th width="200" class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $gudeps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gudep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e(($gudeps->currentPage()-1) * $gudeps->perPage() + $loop->iteration); ?></td>
                        <td>
                            <?php if($gudep->logo): ?>
                                <img src="<?php echo e(asset('storage/' . $gudep->logo)); ?>" class="rounded" width="50" height="50" style="object-fit: cover;">
                            <?php else: ?>
                                <div class="bg-light rounded d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                    <i class="fas fa-image text-muted"></i>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="fw-bold fs-6"><?php echo e($gudep->pangkalan_name); ?></div>
                            <div class="text-primary small fw-bold">Gudep: <?php echo e($gudep->gudep_number); ?></div>
                            <small class="text-muted"><a href="<?php echo e(route('gudep.show', $gudep->slug)); ?>" target="_blank" class="text-decoration-none">Lihat Profil <i class="fas fa-external-link-alt ms-1" style="font-size: 0.7rem;"></i></a></small>
                        </td>
                        <td><span class="badge bg-info text-dark"><?php echo e(number_format($gudep->active_members_count)); ?> Anggota</span></td>
                        <td>
                            <?php if($gudep->is_active): ?>
                                <span class="badge bg-success">Aktif</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Non-Aktif</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <div class="btn-group">
                                <a href="<?php echo e(route('gudep.show', $gudep->slug)); ?>" class="btn btn-sm btn-info text-white" target="_blank" title="Lihat"><i class="fas fa-eye"></i></a>
                                <?php $canEdit = auth()->user()->role === 'admin' || (auth()->user()->role === 'operator_gudep' && $gudep->user_id === auth()->id()); ?>
                                <?php if($canEdit): ?>
                                    <a href="<?php echo e(route('admin.gudep.edit', $gudep->id)); ?>" class="btn btn-sm btn-warning" title="Edit"><i class="fas fa-edit"></i></a>
                                    <form action="<?php echo e(route('admin.gudep.destroy', $gudep->id)); ?>" method="POST" onsubmit="return confirm('Hapus Gudep ini?')">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger" title="Hapus"><i class="fas fa-trash"></i></button>
                                    </form>
                                <?php else: ?>
                                    <span class="btn btn-sm btn-secondary disabled" title="Bukan milik Anda"><i class="fas fa-lock"></i></span>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-4">Belum ada data Gudep.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="mt-4">
            <?php echo e($gudeps->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/admin/gudep/index.blade.php ENDPATH**/ ?>