

<?php $__env->startSection('page_title', 'Agenda Kegiatan LPK'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="m-0 fw-bold">Daftar Agenda LPK</h5>
        <a href="<?php echo e(route('admin.lpk.agendas.create')); ?>" class="btn btn-primary btn-sm">+ Tambah Agenda</a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>Agenda</th>
                        <th>Lokasi</th>
                        <th>Status</th>
                        <th class="text-end">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $agendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agenda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($agenda->date->format('d/m/Y')); ?> <?php if($agenda->time): ?><br><small class="text-muted"><?php echo e($agenda->time); ?></small><?php endif; ?></td>
                        <td>
                            <div class="fw-bold"><?php echo e($agenda->title); ?></div>
                            <small class="text-muted"><?php echo e(Str::limit($agenda->description, 50)); ?></small>
                        </td>
                        <td><?php echo e($agenda->location ?: '-'); ?></td>
                        <td>
                            <?php if($agenda->is_public): ?>
                                <span class="badge bg-success">Publik</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Internal</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-end">
                            <div class="btn-group">
                                <a href="<?php echo e(route('admin.lpk.agendas.edit', $agenda->id)); ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i></a>
                                <form action="<?php echo e(route('admin.lpk.agendas.destroy', $agenda->id)); ?>" method="POST" onsubmit="return confirm('Hapus agenda ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center py-4 text-muted">Belum ada agenda kegiatan.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="mt-3">
            <?php echo e($agendas->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/admin/lpk/agendas/index.blade.php ENDPATH**/ ?>