

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Edit Widget</h5>
    </div>
    <div class="card-body">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('admin.sidebar-widgets.update', $sidebarWidget)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-3">
                <label class="form-label">Nama (internal)</label>
                <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $sidebarWidget->name)); ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Judul (tampil)</label>
                <input type="text" name="title" class="form-control" value="<?php echo e(old('title', $sidebarWidget->title)); ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Tipe</label>
                <select name="type" class="form-select" required>
                    <option value="agenda" <?php echo e($sidebarWidget->type=='agenda' ? 'selected' : ''); ?>>Agenda</option>
                    <option value="popular" <?php echo e($sidebarWidget->type=='popular' ? 'selected' : ''); ?>>Popular Posts</option>
                    <option value="visitor" <?php echo e($sidebarWidget->type=='visitor' ? 'selected' : ''); ?>>Statistik Pengunjung</option>
                    <option value="html" <?php echo e($sidebarWidget->type=='html' ? 'selected' : ''); ?>>Custom HTML</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Konten (untuk HTML)</label>
                <textarea name="content" class="form-control" rows="4"><?php echo e(old('content', $sidebarWidget->content)); ?></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">URL (opsional)</label>
                <input type="url" name="url" class="form-control" value="<?php echo e(old('url', $sidebarWidget->url)); ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Urutan (Order)</label>
                <input type="number" name="order" class="form-control" value="<?php echo e(old('order', $sidebarWidget->order)); ?>">
            </div>

            <div class="mb-3 form-check">
                <input type="checkbox" name="is_active" class="form-check-input" id="is_active" <?php echo e($sidebarWidget->is_active ? 'checked' : ''); ?>>
                <label class="form-check-label" for="is_active">Aktif</label>
            </div>

            <button class="btn btn-primary">Simpan</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/admin/sidebar_widgets/edit.blade.php ENDPATH**/ ?>