

<?php $__env->startSection('page_title', 'Manajemen User'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="m-0 fw-bold">Daftar User</h5>
        <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary btn-sm rounded-pill"><i class="fas fa-plus me-1"></i> Tambah User</a>
    </div>
    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="bg-light">
                    <tr>
                        <th width="5%">#</th>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Terdaftar</th>
                        <th width="15%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration + $users->firstItem() - 1); ?></td>
                        <td class="fw-semibold"><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td>
                            <?php if($user->role === 'admin'): ?>
                                <span class="badge bg-danger rounded-pill">Admin</span>
                            <?php elseif($user->role === 'humas'): ?>
                                <span class="badge bg-info rounded-pill">Humas</span>
                            <?php elseif($user->role === 'lpk'): ?>
                                <span class="badge bg-success rounded-pill">LPK</span>
                            <?php elseif($user->role === 'operator_gudep'): ?>
                                <span class="badge bg-primary rounded-pill">Op. Gudep</span>
                            <?php elseif($user->role === 'dkr'): ?>
                                <span class="badge bg-warning text-dark rounded-pill">Op. DKR</span>
                            <?php else: ?>
                                <span class="badge bg-secondary rounded-pill">User</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($user->created_at->format('d M Y')); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-info btn-sm text-white rounded-circle"><i class="fas fa-pencil-alt"></i></a>
                            <?php if($user->id !== auth()->id()): ?>
                            <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus user ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger btn-sm rounded-circle"><i class="fas fa-trash"></i></button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-4 text-muted">Belum ada user</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="mt-3">
            <?php echo e($users->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/admin/users/index.blade.php ENDPATH**/ ?>