

<?php $__env->startSection('title', 'Semua Berita - Kwarran Bekasi Timur'); ?>

<?php $__env->startSection('content'); ?>

<div class="container mb-5">
    <div class="row">
        <!-- Main Content -->
        <!-- Main Content -->
        <div class="col-lg-8">
            <h2 class="fw-bold mb-4 border-bottom pb-2" style="border-color: var(--secondary-color) !important;">Berita Terbaru</h2>
            <?php if($posts->count() > 0): ?>
                <div class="row">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12 mb-4">
                    <article class="card h-100 border-0 shadow-sm overflow-hidden flex-row">
                        <?php
                            $thumbnail = null;
                            if ($post->featured_image) {
                                $thumbnail = asset('storage/' . $post->featured_image);
                            } elseif ($post->youtube_url) {
                                preg_match('/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/', $post->youtube_url, $matches);
                                if (isset($matches[1])) {
                                    $thumbnail = "https://img.youtube.com/vi/{$matches[1]}/mqdefault.jpg";
                                }
                            }
                        ?>

                        <?php if($thumbnail): ?>
                        <div class="col-4 position-relative overflow-hidden">
                            <img src="<?php echo e($thumbnail); ?>" class="img-fluid w-100 h-100" alt="<?php echo e($post->title); ?>" style="object-fit: cover;">
                            <?php if($post->category): ?>
                            <div class="position-absolute top-0 start-0 bg-warning text-dark px-2 py-1 small fw-bold m-2 rounded"><?php echo e($post->category->name); ?></div>
                            <?php endif; ?>
                            <?php if(!$post->featured_image && $post->youtube_url): ?>
                            <div class="position-absolute top-50 start-50 translate-middle">
                                <i class="fab fa-youtube fa-3x text-danger bg-white rounded-circle p-1"></i>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                        <div class="col-<?php echo e($thumbnail ? '8' : '12'); ?>">
                            <div class="card-body d-flex flex-column h-100 p-3">
                                <div class="text-muted small mb-2">
                                    <i class="far fa-calendar-alt me-1"></i> <?php echo e($post->published_at?->format('d M Y')); ?>

                                    <span class="mx-1">•</span>
                                    <i class="far fa-user me-1"></i> <?php echo e($post->author); ?>

                                </div>
                                <h5 class="card-title fw-bold mb-2">
                                    <a href="<?php echo e(route('posts.show', $post->slug)); ?>" class="text-decoration-none text-dark stretched-link">
                                        <?php echo e(Str::limit($post->title, 60)); ?>

                                    </a>
                                </h5>
                                <p class="card-text text-muted small mb-3 flex-grow-1"><?php echo e(Str::limit(strip_tags($post->excerpt ?? $post->content), 100)); ?></p>
                                <div class="mt-auto">
                                    <span class="text-primary fw-bold small">Baca Selengkapnya <i class="fas fa-arrow-right ms-1"></i></span>
                                </div>
                            </div>
                        </div>
                    </article>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
                <!-- Pagination -->
                <div class="mt-4">
                    <?php echo e($posts->links()); ?>

                </div>
            <?php else: ?>
            <div class="alert alert-info py-4" role="alert">
                <div class="text-center">
                    <i class="fas fa-newspaper fa-3x mb-3 text-info opacity-50"></i>
                    <h5 class="alert-heading fw-bold">Belum Ada Berita</h5>
                    <p class="mb-0">Saat ini belum ada artikel berita yang tersedia. Silakan kembali lagi nanti.</p>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Sidebar -->
        <div class="col-lg-4">
            <?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/posts/index.blade.php ENDPATH**/ ?>