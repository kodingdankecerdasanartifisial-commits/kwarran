<?php if(isset($sidebarWidgets) && $sidebarWidgets->count()): ?>
    <?php $__currentLoopData = $sidebarWidgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $widget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="sidebar-card bg-white shadow mb-4 p-3">
            <?php if($widget->title): ?>
                <h5 class="mb-2 font-semibold"><?php echo e($widget->title); ?></h5>
            <?php endif; ?>

            <?php if($widget->type === 'agenda'): ?>
                <?php
                    $events = \App\Models\Event::whereDate('event_date', '>=', now())->orderBy('event_date')->take(5)->get();
                ?>
                <?php if($events->count()): ?>
                    <ul class="list-unstyled">
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="mb-2">
                                <a href="<?php echo e(route('agenda.index')); ?>" class="d-block text-decoration-none"><?php echo e(Str::limit($e->title, 80)); ?></a>
                                <small class="text-muted"><?php echo e($e->event_date->format('d M Y')); ?><?php if($e->end_date): ?> - <?php echo e($e->end_date->format('d M Y')); ?><?php endif; ?></small>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php else: ?>
                    <div class="text-sm text-muted">Belum ada agenda mendatang.</div>
                <?php endif; ?>

            <?php elseif($widget->type === 'popular'): ?>
                <?php if(isset($popularPosts) && $popularPosts->count()): ?>
                    <div class="popular-posts-widget">
                        <?php $__currentLoopData = $popularPosts->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($index === 0): ?>
                                
                                <div class="mb-3">
                                    <a href="<?php echo e(route('posts.show', $post->slug)); ?>" class="d-block text-decoration-none">
                                        <div class="ratio ratio-16x9 mb-2">
                                            <img src="<?php echo e($post->featured_image ? asset('storage/' . $post->featured_image) : 'https://via.placeholder.com/300x200'); ?>" alt="<?php echo e($post->title); ?>" class="img-fluid rounded object-fit-cover">
                                        </div>
                                        <h6 class="fw-bold text-dark mb-1"><?php echo e(Str::limit($post->title, 80)); ?></h6>
                                        <div class="text-muted small"><?php echo e($post->published_at?->format('d M Y')); ?></div>
                                    </a>
                                </div>
                                <?php if($popularPosts->count() > 1): ?>
                                    <hr class="my-3">
                                    <ul class="list-unstyled mb-0">
                                <?php endif; ?>
                            <?php else: ?>
                                
                                <li class="mb-2">
                                    <a href="<?php echo e(route('posts.show', $post->slug)); ?>" class="text-decoration-none text-dark d-flex align-items-start">
                                        <i class="fas fa-angle-right mt-1 me-2 text-warning"></i>
                                        <span><?php echo e(Str::limit($post->title, 60)); ?></span>
                                    </a>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($popularPosts->count() > 1): ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div class="text-sm text-muted">Belum ada artikel populer.</div>
                <?php endif; ?>

            <?php elseif($widget->type === 'visitor'): ?>
                <div class="visitor-stats p-2">
                    <div class="d-flex justify-content-between mb-2 small">
                        <span><i class="fas fa-user-clock me-2 text-primary"></i>Online:</span>
                        <span class="fw-bold"><?php echo e(number_format($visitorStats['online'] ?? 0)); ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2 small">
                        <span><i class="fas fa-user-plus me-2 text-success"></i>Hari Ini:</span>
                        <span class="fw-bold"><?php echo e(number_format($visitorStats['today'] ?? 0)); ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2 small">
                        <span><i class="fas fa-calendar-day me-2 text-info"></i>Kemarin:</span>
                        <span class="fw-bold"><?php echo e(number_format($visitorStats['yesterday'] ?? 0)); ?></span>
                    </div>
                    <div class="d-flex justify-content-between small">
                        <span><i class="fas fa-users me-2 text-warning"></i>Total:</span>
                        <span class="fw-bold"><?php echo e(number_format($visitorStats['total'] ?? 0)); ?></span>
                    </div>
                </div>

            <?php elseif($widget->type === 'html'): ?>
                <div class="widget-content-html">
                    <?php echo $widget->content; ?>

                </div>
            <?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <div class="sidebar-card bg-white shadow">
        <!-- Profile Banner -->
        <div class="profile-banner bg-gradient-to-r from-yellow-400 to-red-600 text-white">
            <div class="p-6 text-center">
                <?php
                    $profileImage = \App\Models\Setting::get('sidebar_profile_image');
                    $profileName = \App\Models\Setting::get('sidebar_profile_name', 'Kak GKR Hayu');
                    $profileBio = \App\Models\Setting::get('sidebar_profile_bio', 'Tokoh & Pembina');
                    $profileLink = \App\Models\Setting::get('sidebar_profile_link', '#');
                ?>

                <img src="<?php echo e($profileImage ? asset('storage/' . $profileImage) : 'https://via.placeholder.com/140'); ?>" alt="<?php echo e($profileName); ?>" class="mx-auto rounded-circle img-fluid" style="width:100%;max-width:140px;height:auto;border:4px solid #fff;">
                <h3 class="mt-3 font-semibold text-lg"><?php echo e($profileName); ?></h3>
                <p class="text-sm opacity-90"><?php echo e($profileBio); ?></p>
                <a href="<?php echo e($profileLink); ?>" class="mt-3 inline-block bg-white text-[#4B2C20] font-semibold px-4 py-2 rounded-full shadow-sm">Profil</a>
            </div>
        </div>

        <!-- Popular Articles -->
        <div class="p-4">
            <h4 class="font-semibold mb-3">Sering Banget Dibaca</h4>
            <ul class="space-y-4">
                <?php if(isset($popularPosts) && $popularPosts->count()): ?>
                    <div class="popular-posts-widget">
                        <?php $__currentLoopData = $popularPosts->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($index === 0): ?>
                                <div class="mb-3">
                                    <a href="<?php echo e(route('posts.show', $post->slug)); ?>" class="d-block text-decoration-none">
                                        <div class="ratio ratio-16x9 mb-2">
                                            <img src="<?php echo e($post->featured_image ? asset('storage/' . $post->featured_image) : 'https://via.placeholder.com/300x200'); ?>" alt="<?php echo e($post->title); ?>" class="img-fluid rounded object-fit-cover">
                                        </div>
                                        <h6 class="fw-bold text-dark mb-1"><?php echo e(Str::limit($post->title, 80)); ?></h6>
                                        <div class="text-muted small"><?php echo e($post->published_at?->format('d M Y')); ?></div>
                                    </a>
                                </div>
                                <?php if($popularPosts->count() > 1): ?>
                                    <hr class="my-3">
                                    <ul class="list-unstyled mb-0">
                                <?php endif; ?>
                            <?php else: ?>
                                <li class="mb-2">
                                    <a href="<?php echo e(route('posts.show', $post->slug)); ?>" class="text-decoration-none text-dark d-flex align-items-start">
                                        <i class="fas fa-angle-right mt-1 me-2 text-warning"></i>
                                        <span><?php echo e(Str::limit($post->title, 60)); ?></span>
                                    </a>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($popularPosts->count() > 1): ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div class="text-sm text-muted">Belum ada artikel populer.</div>
                <?php endif; ?>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\kwarran\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>