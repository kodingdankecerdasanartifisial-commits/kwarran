

<?php $__env->startSection('title', $post->title . ' - Kwarran Bekasi Timur'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Header -->


<div class="container mb-5">
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-decoration-none" style="color: var(--primary-color);">Beranda</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('posts.index')); ?>" class="text-decoration-none" style="color: var(--primary-color);">Berita</a></li>
            <?php if($post->category): ?>
            <li class="breadcrumb-item"><a href="<?php echo e(route('categories.show', $post->category->slug)); ?>" class="text-decoration-none" style="color: var(--primary-color);"><?php echo e($post->category->name); ?></a></li>
            <?php endif; ?>
            <li class="breadcrumb-item active"><?php echo e(Str::limit($post->title, 50)); ?></li>
        </ol>
    </nav>

    <div class="row">
        <!-- Main Content -->
        <div class="col-lg-8">
            <article class="card border-0 shadow-sm rounded-3 overflow-hidden mb-4">
                <?php if($post->featured_image): ?>
                <img src="<?php echo e(asset('storage/' . $post->featured_image)); ?>" class="img-fluid w-100" alt="<?php echo e($post->title); ?>" style="max-height: 500px; object-fit: cover;">
                <?php endif; ?>
                
                <div class="card-body p-4 p-md-5">
                    <!-- Post Meta -->
                    <div class="mb-4">
                        <?php if($post->category): ?>
                        <a href="<?php echo e(route('categories.show', $post->category->slug)); ?>" class="post-category">
                            <?php echo e($post->category->name); ?>

                        </a>
                        <?php endif; ?>
                        <h1 class="fw-bold mt-2"><?php echo e($post->title); ?></h1>
                    </div>

                    <!-- Post Meta Info -->
                    <div class="d-flex flex-wrap gap-3 text-muted mb-4 pb-3 border-bottom">
                        <small><i class="far fa-calendar-alt me-1"></i> <?php echo e($post->published_at?->format('d F Y')); ?></small>
                        <small><i class="far fa-user me-1"></i> <?php echo e($post->author); ?></small>
                        <small><i class="far fa-folder me-1"></i> <?php echo e($post->category?->name ?? 'Uncategorized'); ?></small>
                    </div>

                    <!-- Post Content -->
                    <div class="post-content">
                        <?php if($post->youtube_url): ?>
                        <div class="ratio ratio-16x9 mb-4 rounded overflow-hidden shadow-sm">
                            <iframe src="https://www.youtube.com/embed/<?php echo e(\Illuminate\Support\Str::after($post->youtube_url, 'v=')); ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                        <?php endif; ?>

                        <?php if($post->material_pdf): ?>
                        <div class="card bg-light border-0 mb-4">
                            <div class="card-body d-flex align-items-center">
                                <i class="fas fa-file-pdf fa-3x text-danger me-3"></i>
                                <div>
                                    <h6 class="fw-bold mb-1">Dokumen Materi</h6>
                                    <p class="small text-muted mb-2">Klik tombol di bawah untuk melihat atau mengunduh materi.</p>
                                    <a href="<?php echo e(asset('storage/' . $post->material_pdf)); ?>" class="btn btn-sm btn-outline-danger" target="_blank">
                                        <i class="fas fa-download me-1"></i> Download PDF
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php echo $post->content; ?>

                    </div>

                    <!-- Share Buttons -->
                    <div class="mt-5 pt-4 border-top">
                        <h6 class="fw-bold mb-3">BAGIKAN ARTIKEL:</h6>
                        <div class="d-flex flex-wrap gap-2">
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(url()->current()); ?>" class="btn btn-sm btn-outline-dark" target="_blank">
                                <i class="fab fa-facebook-f me-2"></i>Facebook
                            </a>
                            <a href="https://twitter.com/intent/tweet?url=<?php echo e(url()->current()); ?>&text=<?php echo e($post->title); ?>" class="btn btn-sm btn-outline-dark" target="_blank">
                                <i class="fab fa-twitter me-2"></i>Twitter
                            </a>
                            <a href="https://wa.me/?text=<?php echo e($post->title); ?> <?php echo e(url()->current()); ?>" class="btn btn-sm btn-outline-dark" target="_blank">
                                <i class="fab fa-whatsapp me-2"></i>WhatsApp
                            </a>
                        </div>
                    </div>
                </div>
            </article>

            <!-- Related Posts -->
            <?php if($relatedPosts->count() > 0): ?>
            <section class="mt-5">
                <h4 class="fw-bold mb-4">ARTIKEL TERKAIT</h4>
                <div class="row">
                    <?php $__currentLoopData = $relatedPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 mb-3">
                        <div class="card post-card h-100 shadow-sm border-0">
                            <?php if($relatedPost->featured_image): ?>
                            <a href="<?php echo e(route('posts.show', $relatedPost->slug)); ?>">
                                <img src="<?php echo e(asset('storage/' . $relatedPost->featured_image)); ?>" class="card-img-top" alt="<?php echo e($relatedPost->title); ?>" style="height: 180px; object-fit: cover;">
                            </a>
                            <?php endif; ?>
                            <div class="card-body">
                                <div class="text-muted small mb-2"><i class="far fa-calendar-alt me-1"></i> <?php echo e($relatedPost->published_at?->format('d M Y')); ?></div>
                                <h6 class="card-title fw-bold">
                                    <a href="<?php echo e(route('posts.show', $relatedPost->slug)); ?>" class="text-decoration-none text-dark">
                                        <?php echo e(Str::limit($relatedPost->title, 50)); ?>

                                    </a>
                                </h6>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
            <?php endif; ?>
        </div>

        <!-- Sidebar -->
        <div class="col-lg-4">
            <?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
    </div>
</div>

<style>
    .post-content {
        line-height: 1.8;
        font-size: 1.1rem;
        color: #333;
    }
    .post-content p { margin-bottom: 1.5rem; }
    .post-content img {
        max-width: 100%;
        height: auto;
        margin: 20px 0;
        border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    }
    .post-content h2, .post-content h3 {
        margin-top: 30px;
        margin-bottom: 20px;
        font-weight: 700;
        color: var(--primary-color);
    }
    .post-content blockquote {
        background: #f9f9f9;
        border-left: 5px solid var(--secondary-color);
        padding: 20px 30px;
        margin: 30px 0;
        font-style: italic;
        font-size: 1.2rem;
    }
</style>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/posts/show.blade.php ENDPATH**/ ?>