

<?php $__env->startSection('title', $album->name . ' - Galeri DKR'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('dkr.index')); ?>">DKR</a></li>
            <li class="breadcrumb-item active" aria-current="page">Album: <?php echo e($album->name); ?></li>
        </ol>
    </nav>

    <div class="text-center mb-5">
        <h1 class="display-5 fw-bold text-dark text-uppercase mb-2"><?php echo e($album->name); ?></h1>
        <p class="text-muted lead"><?php echo e($album->description); ?></p>
        <div class="badge bg-primary px-3 py-2 rounded-pill"><i class="fas fa-calendar-alt me-1"></i> <?php echo e($album->created_at->format('d M Y')); ?></div>
        <div class="badge bg-secondary px-3 py-2 rounded-pill"><i class="fas fa-camera me-1"></i> <?php echo e($album->photos->count()); ?> Foto</div>
    </div>

    <div class="row g-3">
        <?php $__currentLoopData = $album->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 col-lg-3 col-6">
            <div class="card border-0 shadow-sm rounded-4 overflow-hidden gallery-card h-100">
                <a href="<?php echo e(asset('storage/' . $photo->image)); ?>" data-lightbox="dkr-album" data-title="<?php echo e($photo->caption); ?>">
                    <img src="<?php echo e(asset('storage/' . $photo->image)); ?>" class="img-fluid post-card-hover" style="height: 200px; width: 100%; object-fit: cover;" alt="Galeri">
                </a>
                <?php if($photo->caption): ?>
                <div class="card-body p-2 text-center">
                    <small class="text-muted fst-italic"><?php echo e($photo->caption); ?></small>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="text-center mt-5">
        <a href="<?php echo e(route('dkr.index')); ?>" class="btn btn-outline-primary px-5 rounded-pill fw-bold">KEMBALI KE HALAMAN DKR</a>
    </div>
</div>

<style>
    .gallery-card { transition: all 0.3s ease; }
    .gallery-card:hover { transform: scale(1.02); }
    .post-card-hover { transition: all 0.3s ease; }
    .post-card-hover:hover { filter: brightness(0.8); }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/dkr/album_show.blade.php ENDPATH**/ ?>