<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulir Input Data: <?php echo e($form->title); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background-color: #f0f2f5; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .form-container { max-width: 650px; margin: 40px auto; }
        .form-header { 
            background: linear-gradient(135deg, #4B2C20 0%, #6d4130 100%); 
            color: white; 
            border-top-left-radius: 12px; 
            border-top-right-radius: 12px;
            padding: 30px;
            border-bottom: 5px solid #F2C94C;
        }
        .form-card { background: white; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        .form-body { padding: 30px; }
        .field-group { margin-bottom: 25px; }
        .form-label { font-weight: 600; color: #333; }
        .btn-submit { background-color: #4B2C20; color: white; padding: 12px 30px; border-radius: 8px; font-weight: 600; }
        .btn-submit:hover { background-color: #5d3728; color: white; }
    </style>
</head>
<body>
    <div class="form-container">
        <div class="form-card">
            <div class="form-header">
                <h2 class="mb-2"><?php echo e($form->title); ?></h2>
                <p class="mb-0 opacity-75"><?php echo e($form->description); ?></p>
            </div>
            <div class="form-body">
                <?php if(session('success')): ?>
                    <div class="alert alert-success border-0 shadow-sm rounded-3 mb-4">
                        <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('sisran.public.store', $form->slug)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    
                    <div class="bg-light p-3 rounded-3 mb-4">
                        <h6 class="fw-bold mb-3 border-bottom pb-2">Informasi Pelapor / Unit</h6>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label small">Nama Lengkap Operator</label>
                                <input type="text" name="operator_name" class="form-control" placeholder="Contoh: Kak Ahmad" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small">Utusan / Unit / Gugus Depan</label>
                                <input type="text" name="operator_unit" class="form-control" placeholder="Contoh: Sanggar Bakti 01.001" required>
                            </div>
                        </div>
                    </div>

                    <h6 class="fw-bold mb-3 border-bottom pb-2">Data Isian Statistik</h6>
                    
                    <?php $__currentLoopData = $form->fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="field-group">
                        <label class="form-label"><?php echo e($field->label); ?> <?php if($field->is_required): ?><span class="text-danger">*</span><?php endif; ?></label>
                        
                        <?php if($field->type === 'number'): ?>
                            <input type="number" name="values[<?php echo e($field->id); ?>]" class="form-control" placeholder="Masukkan angka..." <?php echo e($field->is_required ? 'required' : ''); ?>>
                        <?php elseif($field->type === 'select'): ?>
                            <select name="values[<?php echo e($field->id); ?>]" class="form-select" <?php echo e($field->is_required ? 'required' : ''); ?>>
                                <option value="">Pilih opsi...</option>
                                <?php $__currentLoopData = explode(',', $field->options); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e(trim($option)); ?>"><?php echo e(trim($option)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php elseif($field->type === 'radio'): ?>
                            <div class="mt-2">
                                <?php $__currentLoopData = explode(',', $field->options); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="values[<?php echo e($field->id); ?>]" id="opt_<?php echo e($field->id); ?>_<?php echo e($loop->index); ?>" value="<?php echo e(trim($option)); ?>" <?php echo e($field->is_required ? 'required' : ''); ?>>
                                    <label class="form-check-label" for="opt_<?php echo e($field->id); ?>_<?php echo e($loop->index); ?>">
                                        <?php echo e(trim($option)); ?>

                                    </label>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php elseif($field->type === 'checkbox'): ?>
                            <div class="mt-2">
                                <?php $__currentLoopData = explode(',', $field->options); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="values[<?php echo e($field->id); ?>][]" id="opt_<?php echo e($field->id); ?>_<?php echo e($loop->index); ?>" value="<?php echo e(trim($option)); ?>">
                                    <label class="form-check-label" for="opt_<?php echo e($field->id); ?>_<?php echo e($loop->index); ?>">
                                        <?php echo e(trim($option)); ?>

                                    </label>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                            <input type="text" name="values[<?php echo e($field->id); ?>]" class="form-control" placeholder="Masukkan teks..." <?php echo e($field->is_required ? 'required' : ''); ?>>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="text-center mt-4 pt-3">
                        <button type="submit" class="btn btn-submit shadow-sm w-100">
                            <i class="fas fa-paper-plane me-2"></i>Kirim Laporan Data
                        </button>
                        <p class="small text-muted mt-3">Sistem Informasi Statistik Kwarran Bekasi Timur</p>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\kwarran\resources\views/pages/sisran/fill.blade.php ENDPATH**/ ?>