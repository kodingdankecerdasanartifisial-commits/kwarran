

<?php $__env->startSection('page_title', 'Kalender Arus Kas'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="m-0 fw-bold">Riwayat Keuangan Bulanan</h5>
        <a href="<?php echo e(route('admin.finances.index')); ?>" class="btn btn-secondary btn-sm rounded-pill">
            <i class="fas fa-list me-1"></i> Lihat Tabel
        </a>
    </div>
    <div class="card-body">
        <div id="calendar" style="min-height: 600px;"></div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js'></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');
        var calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            locale: 'id',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek'
            },
            events: <?php echo json_encode($events); ?>,
            eventClick: function(info) {
                alert('Keterangan: ' + info.event.extendedProps.description + '\n' + info.event.title);
            }
        });
        calendar.render();
    });
</script>
<style>
    .fc-event {
        cursor: pointer;
        padding: 2px 5px;
        border-radius: 4px;
        font-size: 0.85em;
    }
    .fc-toolbar-title {
        font-weight: bold;
        text-transform: capitalize;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/admin/finances/calendar.blade.php ENDPATH**/ ?>