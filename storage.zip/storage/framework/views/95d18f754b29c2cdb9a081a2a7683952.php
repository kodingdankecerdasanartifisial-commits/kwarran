

<?php $__env->startSection('title', 'Kontak - ' . config('app.name')); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row mb-4">
        <div class="col-md-8 offset-md-2 text-center">
            <h1 class="fw-bold display-5">Kontak Kami</h1>
            <p class="text-muted">Hubungi Kwartir Ranting Bekasi Timur untuk pertanyaan atau informasi lebih lanjut.</p>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <div class="card p-4 mb-4">
                <h5 class="fw-bold">Informasi Kontak</h5>
                <p class="mb-1"><i class="fas fa-map-marker-alt me-2"></i> <?php echo e(\App\Models\Setting::get('address', 'Kec. Bekasi Timur, Kota Bekasi, Jawa Barat')); ?></p>
                <p class="mb-1"><i class="fas fa-phone me-2"></i> <?php echo e(\App\Models\Setting::get('phone', '+62 ...')); ?></p>
                <p class="mb-0"><i class="fas fa-envelope me-2"></i> <?php echo e(\App\Models\Setting::get('email', 'info@kwarranbekasitimur.id')); ?></p>
                <div class="mt-3">
                    <?php if($fb = \App\Models\Setting::get('social_facebook')): ?> <a href="<?php echo e($fb); ?>" class="text-secondary fs-5 me-3" target="_blank"><i class="fab fa-facebook-f"></i></a> <?php endif; ?>
                    <?php if($ig = \App\Models\Setting::get('social_instagram')): ?> <a href="<?php echo e($ig); ?>" class="text-secondary fs-5 me-3" target="_blank"><i class="fab fa-instagram"></i></a> <?php endif; ?>
                    <?php if($yt = \App\Models\Setting::get('social_youtube')): ?> <a href="<?php echo e($yt); ?>" class="text-secondary fs-5 me-3" target="_blank"><i class="fab fa-youtube"></i></a> <?php endif; ?>
                    <?php if($x = \App\Models\Setting::get('social_x')): ?> <a href="<?php echo e($x); ?>" class="text-secondary fs-5 me-3" target="_blank"><i class="fab fa-twitter"></i></a> <?php endif; ?>
                    <?php if($tt = \App\Models\Setting::get('social_tiktok')): ?> <a href="<?php echo e($tt); ?>" class="text-secondary fs-5 me-3" target="_blank"><i class="fab fa-tiktok"></i></a> <?php endif; ?>
                </div>
            </div>

            <div class="card p-4">
                <h5 class="fw-bold">Kirim Pesan</h5>
                <form method="POST" action="<?php echo e(route('contact.send')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Nama</label>
                        <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name')); ?>" required>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" required>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Pesan</label>
                        <textarea name="message" rows="5" class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required><?php echo e(old('message')); ?></textarea>
                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <?php if(env('RECAPTCHA_SITE_KEY')): ?>
                        <div class="mb-3">
                            <div class="g-recaptcha" data-sitekey="<?php echo e(env('RECAPTCHA_SITE_KEY')); ?>"></div>
                            <?php if($errors->has('captcha')): ?>
                                <div class="text-danger small mt-1"><?php echo e($errors->first('captcha')); ?></div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary">Kirim Pesan</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card p-4 mb-4">
                <h5 class="fw-bold">Lokasi</h5>
                <div class="ratio ratio-16x9 border rounded overflow-hidden">
                    <?php
                        $map = \App\Models\Setting::get('maps_embed');
                    ?>
                    <?php if($map): ?>
                        <?php echo $map; ?>

                    <?php else: ?>
                        <iframe src="https://www.google.com/maps?q=Bekasi+Timur&output=embed" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card p-4">
                <h5 class="fw-bold">Jam Operasional</h5>
                <p class="mb-0">Senin - Jumat: 08:00 - 16:00</p>
                <p>Sabtu - Minggu: Tutup</p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php if(env('RECAPTCHA_SITE_KEY')): ?>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/pages/contact.blade.php ENDPATH**/ ?>