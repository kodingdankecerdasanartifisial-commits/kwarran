

<?php $__env->startSection('page_title', 'Album Galeri DKR'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="m-0 fw-bold text-dark text-uppercase">Album Galeri DKR</h5>
        <a href="<?php echo e(route('admin.dkr.albums.create')); ?>" class="btn btn-primary btn-sm">
            <i class="fas fa-plus me-1"></i> Buat Album Baru
        </a>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">Album</th>
                        <th>Jumlah Foto</th>
                        <th>Tanggal Dibuat</th>
                        <th class="text-end pe-4">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="ps-4">
                            <div class="d-flex align-items-center">
                                <?php if($album->cover_image): ?>
                                    <img src="<?php echo e(asset('storage/' . $album->cover_image)); ?>" alt="Cover" class="rounded me-3 shadow-sm" style="width: 60px; height: 45px; object-fit: cover;">
                                <?php else: ?>
                                    <div class="bg-light rounded me-3 d-flex align-items-center justify-content-center border" style="width: 60px; height: 45px;"><i class="fas fa-images text-muted"></i></div>
                                <?php endif; ?>
                                <div>
                                    <div class="fw-bold text-dark"><?php echo e($album->name); ?></div>
                                    <small class="text-muted"><?php echo e(Str::limit($album->description, 50)); ?></small>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="badge bg-info"><?php echo e($album->photos->count()); ?> Foto</span>
                        </td>
                        <td>
                            <?php echo e($album->created_at->format('d/m/Y')); ?>

                        </td>
                        <td class="text-end pe-4">
                            <div class="btn-group">
                                <a href="<?php echo e(route('admin.dkr.albums.edit', $album->id)); ?>" class="btn btn-sm btn-outline-primary" title="Edit Album">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('admin.dkr.albums.destroy', $album->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Hapus album ini beserta seluruh fotonya?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Hapus"><i class="fas fa-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="text-center py-5 text-muted">Belum ada album galeri.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="card-footer bg-white">
        <?php echo e($albums->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/admin/dkr/albums/index.blade.php ENDPATH**/ ?>