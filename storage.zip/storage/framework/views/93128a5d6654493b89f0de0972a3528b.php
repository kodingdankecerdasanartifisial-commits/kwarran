

<?php $__env->startSection('page_title', 'Agenda Kerja DKR'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-4">
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-white"><h5 class="m-0 fw-bold">Tambah Agenda Baru</h5></div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.dkr.agendas.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label fw-bold small">Judul Agenda</label>
                        <input type="text" name="title" class="form-control" placeholder="Contoh: Rapat Kerja Cabang" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold small">Tanggal</label>
                        <input type="date" name="date" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold small">Waktu (Opsional)</label>
                        <input type="text" name="time" class="form-control" placeholder="Jam 08:00 - Selesai">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold small">Lokasi</label>
                        <input type="text" name="location" class="form-control" placeholder="Gedung Kwarcab">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold small">Keterangan</label>
                        <textarea name="description" class="form-control" rows="3" placeholder="Detail kegiatan..."></textarea>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-save me-1"></i> SIMPAN AGENDA</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <div class="card shadow-sm">
            <div class="card-header bg-white"><h5 class="m-0 fw-bold">Daftar Agenda Kerja</h5></div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Tanggal</th>
                                <th>Agenda</th>
                                <th>Lokasi</th>
                                <th class="text-end pe-4">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $agendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agenda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="ps-4">
                                    <div class="fw-bold"><?php echo e($agenda->date->format('d/m/Y')); ?></div>
                                    <small class="text-muted"><?php echo e($agenda->time); ?></small>
                                </td>
                                <td>
                                    <div class="fw-bold text-dark"><?php echo e($agenda->title); ?></div>
                                    <small class="text-muted"><?php echo e(Str::limit($agenda->description, 50)); ?></small>
                                </td>
                                <td><?php echo e($agenda->location); ?></td>
                                <td class="text-end pe-4">
                                    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editModal<?php echo e($agenda->id); ?>"><i class="fas fa-edit"></i></button>
                                    <form action="<?php echo e(route('admin.dkr.agendas.destroy', $agenda->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Hapus agenda ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                                    </form>

                                    <!-- Edit Modal -->
                                    <div class="modal fade" id="editModal<?php echo e($agenda->id); ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog text-start">
                                            <div class="modal-content">
                                                <form action="<?php echo e(route('admin.dkr.agendas.update', $agenda->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <div class="modal-header">
                                                        <h5 class="modal-title fw-bold">Edit Agenda</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="mb-3">
                                                            <label class="form-label fw-bold small">Judul Agenda</label>
                                                            <input type="text" name="title" class="form-control" value="<?php echo e($agenda->title); ?>" required>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label fw-bold small">Tanggal</label>
                                                            <input type="date" name="date" class="form-control" value="<?php echo e($agenda->date->format('Y-m-d')); ?>" required>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label fw-bold small">Waktu</label>
                                                            <input type="text" name="time" class="form-control" value="<?php echo e($agenda->time); ?>">
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label fw-bold small">Lokasi</label>
                                                            <input type="text" name="location" class="form-control" value="<?php echo e($agenda->location); ?>">
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label fw-bold small">Keterangan</label>
                                                            <textarea name="description" class="form-control" rows="3"><?php echo e($agenda->description); ?></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center py-5 text-muted">Belum ada agenda kerja.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer bg-white">
                <?php echo e($agendas->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/admin/dkr/agendas/index.blade.php ENDPATH**/ ?>