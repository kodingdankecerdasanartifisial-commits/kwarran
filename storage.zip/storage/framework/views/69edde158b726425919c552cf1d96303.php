

<?php $__env->startSection('page_title', request()->routeIs('admin.posts.materi') ? 'Kelola Postingan Materi' : 'Kelola Berita'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="m-0 fw-bold text-dark"><?php echo e(request()->routeIs('admin.posts.materi') ? 'Daftar Materi' : 'Daftar Berita'); ?></h5>
        <div class="d-flex align-items-center gap-3">
            <form method="GET" action="<?php echo e(url()->current()); ?>" class="d-flex align-items-center">
                <select name="category" class="form-select form-select-sm me-2" onchange="this.form.submit()">
                    <option value="">Semua Kategori</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>" <?php echo e(request('category') == $cat->id ? 'selected' : ''); ?>><?php echo e($cat->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <noscript><button type="submit" class="btn btn-sm btn-outline-secondary">Filter</button></noscript>
            </form>
            <a href="<?php echo e(route('admin.posts.create', ['type' => request()->routeIs('admin.posts.materi') ? 'materi' : 'berita'])); ?>" class="btn btn-primary btn-sm">
                <i class="fas fa-plus me-1"></i>
                <?php echo e(request()->routeIs('admin.posts.materi') ? 'Tambah Materi' : 'Tambah Berita'); ?>

            </a>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">Judul</th>
                        <th>Kategori</th>
                        <th>Materi</th>
                        <th>Status</th>
                        <th>Tanggal Post</th>
                        <th class="text-end pe-4">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="ps-4">
                            <div class="d-flex align-items-center">
                                <?php if($post->featured_image): ?>
                                    <img src="<?php echo e(asset('storage/' . $post->featured_image)); ?>" alt="Img" class="rounded me-3" style="width: 50px; height: 50px; object-fit: cover;">
                                <?php elseif($post->youtube_url): ?>
                                    <?php
                                        // Simple regex to get video ID
                                        preg_match('/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/', $post->youtube_url, $matches);
                                        $videoId = $matches[1] ?? null;
                                    ?>
                                    <?php if($videoId): ?>
                                        <img src="https://img.youtube.com/vi/<?php echo e($videoId); ?>/default.jpg" alt="YT" class="rounded me-3" style="width: 50px; height: 50px; object-fit: cover;">
                                    <?php else: ?>
                                        <div class="bg-light rounded me-3 d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;"><i class="fas fa-image text-muted"></i></div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <div class="bg-light rounded me-3 d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;"><i class="fas fa-image text-muted"></i></div>
                                <?php endif; ?>
                                <div>
                                    <div class="fw-bold text-dark"><?php echo e(Str::limit($post->title, 40)); ?></div>
                                    <small class="text-muted"><?php echo e(Str::limit(strip_tags($post->content), 40)); ?></small>
                                </div>
                            </div>
                        </td>
                        <td>
                            <?php if($post->category): ?>
                                <span class="badge bg-secondary"><?php echo e($post->category->name); ?></span>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php if($post->material_pdf): ?>
                                <a href="<?php echo e(asset('storage/' . $post->material_pdf)); ?>" target="_blank" class="btn btn-sm btn-outline-secondary me-1"><i class="fas fa-file-pdf"></i></a>
                            <?php endif; ?>
                            <?php if($post->youtube_url): ?>
                                <a href="<?php echo e($post->youtube_url); ?>" target="_blank" class="btn btn-sm btn-outline-danger"><i class="fab fa-youtube"></i></a>
                            <?php endif; ?>
                            <?php if(!$post->material_pdf && !$post->youtube_url): ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($post->is_published): ?>
                                <span class="badge bg-success">Published</span>
                            <?php else: ?>
                                <span class="badge bg-warning text-dark">Draft</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php echo e($post->published_at?->format('d/m/Y') ?? '-'); ?>

                        </td>
                        <td class="text-end pe-4">
                            <div class="btn-group">
                                <a href="<?php echo e(route('posts.show', $post->slug)); ?>" class="btn btn-sm btn-outline-info" target="_blank" title="Lihat">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="<?php echo e(route('admin.posts.edit', $post->id)); ?>" class="btn btn-sm btn-outline-primary" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <button type="button" class="btn btn-sm btn-outline-danger" title="Hapus" onclick="if(confirm('Hapus berita ini?')) document.getElementById('delete-post-<?php echo e($post->id); ?>').submit();">
                                    <i class="fas fa-trash"></i>
                                </button>
                                <form id="delete-post-<?php echo e($post->id); ?>" action="<?php echo e(route('admin.posts.destroy', $post->id)); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center py-5 text-muted">Belum ada berita.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="card-footer bg-white">
        <?php echo e($posts->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>