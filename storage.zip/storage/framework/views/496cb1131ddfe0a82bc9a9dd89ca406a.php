

<?php $__env->startSection('page_title', 'Manajemen Landing Page DKR'); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('admin.dkr.landingpage.update')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-lg-8">
            <div class="card mb-4">
                <div class="card-header bg-white"><h5 class="m-0 fw-bold">Informasi DKR</h5></div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Nama Lengkap DKR</label>
                        <input type="text" name="name" class="form-control" required value="<?php echo e($dkr->name); ?>">
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold"><i class="fab fa-whatsapp text-success"></i> No. WhatsApp</label>
                            <input type="text" name="whatsapp" class="form-control" value="<?php echo e($dkr->whatsapp); ?>" placeholder="08xxxx">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold"><i class="fas fa-envelope text-danger"></i> Email</label>
                            <input type="email" name="email" class="form-control" value="<?php echo e($dkr->email); ?>" placeholder="dkr@email.com">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold"><i class="fas fa-map-marker-alt text-warning"></i> Alamat Kantor/Sekretariat</label>
                        <textarea name="address" class="form-control" rows="2" placeholder="Jl. Raya ..."><?php echo e($dkr->address); ?></textarea>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Visi</label>
                            <textarea name="vision" class="form-control" rows="3"><?php echo e($dkr->vision); ?></textarea>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Misi</label>
                            <textarea name="mission" class="form-control" rows="3"><?php echo e($dkr->mission); ?></textarea>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-bold small"><i class="fas fa-user-friends text-primary"></i> Total Anggota</label>
                            <input type="number" name="active_members_count" class="form-control form-control-sm" value="<?php echo e($dkr->active_members_count); ?>" min="0">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-bold small"><i class="fas fa-male text-primary"></i> Putra</label>
                            <input type="number" name="male_members_count" class="form-control form-control-sm" value="<?php echo e($dkr->male_members_count); ?>" min="0">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-bold small"><i class="fas fa-female text-danger"></i> Putri</label>
                            <input type="number" name="female_members_count" class="form-control form-control-sm" value="<?php echo e($dkr->female_members_count); ?>" min="0">
                        </div>
                    </div>
                </div>
            </div>

            <!-- Struktur Kepengurusan -->
            <div class="card mb-4">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="m-0 fw-bold">Struktur Dewan Kerja</h5>
                    <button type="button" class="btn btn-sm btn-outline-primary" onclick="addStructure()">+ Tambah Personil</button>
                </div>
                <div class="card-body" id="structure-container">
                    <?php if($dkr->structure): ?>
                        <?php $__currentLoopData = $dkr->structure; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row align-items-end mb-3 border-bottom pb-3 structure-item" id="structure-<?php echo e($index); ?>">
                            <div class="col-md-1">
                                <?php if(!empty($item['photo'])): ?>
                                    <img src="<?php echo e(asset('storage/' . $item['photo'])); ?>" class="rounded shadow-sm" style="width: 40px; height: 55px; object-fit: cover;">
                                <?php else: ?>
                                    <div class="bg-light rounded d-flex align-items-center justify-content-center border" style="width: 40px; height: 55px;"><i class="fas fa-user text-muted small"></i></div>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-3">
                                <label class="small fw-bold">Nama Lengkap</label>
                                <input type="text" name="structure[<?php echo e($index); ?>][name]" class="form-control form-control-sm" value="<?php echo e($item['name']); ?>" required>
                            </div>
                            <div class="col-md-3">
                                <label class="small fw-bold">Jabatan</label>
                                <input type="text" name="structure[<?php echo e($index); ?>][position]" class="form-control form-control-sm" value="<?php echo e($item['position']); ?>" required>
                            </div>
                            <div class="col-md-4">
                                <label class="small fw-bold">Ganti Foto (3x4)</label>
                                <input type="file" name="structure_photos[<?php echo e($index); ?>]" class="form-control form-control-sm" accept="image/*">
                                <input type="hidden" name="structure[<?php echo e($index); ?>][photo]" value="<?php echo e($item['photo'] ?? ''); ?>">
                            </div>
                            <div class="col-md-1 text-end">
                                <button type="button" class="btn btn-sm btn-danger p-1" onclick="document.getElementById('structure-<?php echo e($index); ?>').remove()"><i class="fas fa-trash"></i></button>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
            <!-- Prestasi section follows -->

            <div class="card mb-4">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="m-0 fw-bold">Prestasi & Pencapaian</h5>
                    <button type="button" class="btn btn-sm btn-outline-primary" onclick="addAchievement()">+ Tambah</button>
                </div>
                <div class="card-body" id="achievement-container">
                    <?php if($dkr->achievements): ?>
                        <?php $__currentLoopData = $dkr->achievements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="input-group mb-2" id="achievement-<?php echo e($index); ?>">
                            <input type="text" name="achievements[]" class="form-control" value="<?php echo e($item); ?>" placeholder="Contoh: Juara 1 Lomba ...">
                            <button class="btn btn-outline-danger" type="button" onclick="document.getElementById('achievement-<?php echo e($index); ?>').remove()"><i class="fas fa-trash"></i></button>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
            <!-- Custom HTML Section -->
            <div class="card mb-4">
                <div class="card-header bg-white"><h5 class="m-0 fw-bold">Custom HTML Block</h5></div>
                <div class="card-body">
                    <p class="text-muted small mb-2">Gunakan bagian ini untuk menambahkan widget eksternal, kode embed, atau kustomisasi HTML lainnya di bawah agenda kerja.</p>
                    <textarea name="custom_html" class="form-control" rows="10" placeholder="<div class='my-widget'>...</div>"><?php echo e($dkr->custom_html); ?></textarea>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card mb-4">
                <div class="card-header bg-white"><h5 class="m-0 fw-bold">Video YouTube</h5></div>
                <div class="card-body">
                    <div id="video-container">
                        <?php if($dkr->videos): ?>
                            <?php $__currentLoopData = $dkr->videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="input-group mb-2" id="video-<?php echo e($index); ?>">
                                <span class="input-group-text"><i class="fab fa-youtube text-danger"></i></span>
                                <input type="url" name="videos[]" class="form-control form-control-sm" value="<?php echo e($url); ?>" placeholder="https://youtube.com/...">
                                <button class="btn btn-sm btn-outline-danger" type="button" onclick="document.getElementById('video-<?php echo e($index); ?>').remove()"><i class="fas fa-trash"></i></button>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <button type="button" class="btn btn-sm btn-outline-primary w-100" onclick="addVideo()">+ Tambah Video</button>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header bg-white"><h5 class="m-0 fw-bold">Media Visual</h5></div>
                <div class="card-body">
                    <div class="mb-4">
                        <label class="form-label fw-bold">Logo DKR</label>
                        <?php if($dkr->logo): ?>
                            <div class="mb-2"><img src="<?php echo e(asset('storage/' . $dkr->logo)); ?>" class="img-thumbnail" style="max-height: 100px;"></div>
                        <?php endif; ?>
                        <input type="file" name="logo" class="form-control" accept="image/*">
                    </div>
                    <div class="mb-4">
                        <label class="form-label fw-bold">Hero Image (Banner)</label>
                        <?php if($dkr->hero_image): ?>
                            <div class="mb-2"><img src="<?php echo e(asset('storage/' . $dkr->hero_image)); ?>" class="img-fluid rounded border"></div>
                        <?php endif; ?>
                        <input type="file" name="hero_image" class="form-control" accept="image/*">
                    </div>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header bg-white"><h5 class="m-0 fw-bold">Media Sosial</h5></div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold small"><i class="fab fa-facebook text-primary"></i> Facebook URL</label>
                        <input type="url" name="social_media[facebook]" class="form-control form-control-sm" value="<?php echo e($dkr->social_media['facebook'] ?? ''); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold small"><i class="fab fa-instagram text-danger"></i> Instagram URL</label>
                        <input type="url" name="social_media[instagram]" class="form-control form-control-sm" value="<?php echo e($dkr->social_media['instagram'] ?? ''); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold small"><i class="fab fa-youtube text-danger"></i> YouTube URL</label>
                        <input type="url" name="social_media[youtube]" class="form-control form-control-sm" value="<?php echo e($dkr->social_media['youtube'] ?? ''); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold small"><i class="fab fa-tiktok text-dark"></i> TikTok URL</label>
                        <input type="url" name="social_media[tiktok]" class="form-control form-control-sm" value="<?php echo e($dkr->social_media['tiktok'] ?? ''); ?>">
                    </div>
                </div>
            </div>

            <div class="d-grid gap-2">
                <button type="submit" class="btn btn-primary btn-lg"><i class="fas fa-save me-2"></i>Simpan Perubahan</button>
                <a href="<?php echo e(route('dkr.index')); ?>" target="_blank" class="btn btn-outline-info"><i class="fas fa-external-link-alt me-2"></i>Lihat Halaman DKR</a>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    let structureIndex = <?php echo e(count($dkr->structure ?? [])); ?>;
    function addStructure() {
        // ... index incremented inside ...
        const container = document.getElementById('structure-container');
        const html = `
            <div class="row align-items-end mb-3 border-bottom pb-3 structure-item" id="structure-${structureIndex}">
                <div class="col-md-1">
                    <div class="bg-light rounded d-flex align-items-center justify-content-center border" style="width: 40px; height: 55px;"><i class="fas fa-user text-muted small"></i></div>
                </div>
                <div class="col-md-3">
                    <label class="small fw-bold">Nama Lengkap</label>
                    <input type="text" name="structure[${structureIndex}][name]" class="form-control form-control-sm" required>
                </div>
                <div class="col-md-3">
                    <label class="small fw-bold">Jabatan</label>
                    <input type="text" name="structure[${structureIndex}][position]" class="form-control form-control-sm" required>
                </div>
                <div class="col-md-4">
                    <label class="small fw-bold">Foto (3x4)</label>
                    <input type="file" name="structure_photos[${structureIndex}]" class="form-control form-control-sm" accept="image/*">
                </div>
                <div class="col-md-1 text-end">
                    <button type="button" class="btn btn-sm btn-danger p-1" onclick="document.getElementById('structure-${structureIndex}').remove()"><i class="fas fa-trash"></i></button>
                </div>
            </div>
        `;
        container.insertAdjacentHTML('beforeend', html);
        structureIndex++;
    }

    let achievementIndex = <?php echo e(count($dkr->achievements ?? [])); ?>;
    function addAchievement() {
        const container = document.getElementById('achievement-container');
        const html = `
            <div class="input-group mb-2" id="achievement-${achievementIndex}">
                <input type="text" name="achievements[]" class="form-control" placeholder="Contoh: Juara 1 Lomba ...">
                <button class="btn btn-outline-danger" type="button" onclick="document.getElementById('achievement-${achievementIndex}').remove()"><i class="fas fa-trash"></i></button>
            </div>
        `;
        container.insertAdjacentHTML('beforeend', html);
        achievementIndex++;
    }

    let videoIndex = <?php echo e(count($dkr->videos ?? [])); ?>;
    function addVideo() {
        const container = document.getElementById('video-container');
        const html = `
            <div class="input-group mb-2" id="video-${videoIndex}">
                <span class="input-group-text"><i class="fab fa-youtube text-danger"></i></span>
                <input type="url" name="videos[]" class="form-control form-control-sm" placeholder="https://youtube.com/...">
                <button class="btn btn-sm btn-outline-danger" type="button" onclick="document.getElementById('video-${videoIndex}').remove()"><i class="fas fa-trash"></i></button>
            </div>
        `;
        container.insertAdjacentHTML('beforeend', html);
        videoIndex++;
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/admin/dkr/landingpage.blade.php ENDPATH**/ ?>