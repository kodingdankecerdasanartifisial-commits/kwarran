

<?php $__env->startSection('page_title', 'Visualisasi Data SISRAN'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col">
        <p class="text-muted">Pilih formulir untuk mengatur bagaimana data statistik akan ditampilkan secara publik (grafik batang, lingkaran, dll).</p>
    </div>
</div>

<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-md-6 mb-4">
        <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-body p-4 d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="fw-bold mb-1"><?php echo e($form->title); ?></h5>
                    <p class="small text-muted mb-0"><?php echo e($form->entries_count); ?> Laporan Masuk • <?php echo e($form->category); ?></p>
                </div>
                <a href="<?php echo e(route('admin.sisran.visualize.show', $form)); ?>" class="btn btn-primary rounded-pill px-4">
                    Atur Grafik<i class="fas fa-chevron-right ms-2"></i>
                </a>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-12 text-center py-5">
        <h5>Belum Ada Form SISRAN</h5>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/admin/sisran/visualize_index.blade.php ENDPATH**/ ?>