

<?php $__env->startSection('page_title', 'Inbox Pesan'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="m-0 fw-bold">Inbox Pesan</h5>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Pengirim</th>
                        <th>Email</th>
                        <th>Isi</th>
                        <th>Tanggal</th>
                        <th class="text-end">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="<?php echo e($msg->is_read ? '' : 'table-info'); ?>">
                        <td><?php echo e($msg->name); ?></td>
                        <td><?php echo e($msg->email); ?></td>
                        <td><?php echo e(Str::limit($msg->message, 80)); ?></td>
                        <td><?php echo e($msg->created_at->format('d/m/Y H:i')); ?></td>
                        <td class="text-end">
                            <a href="<?php echo e(route('admin.messages.show', $msg->id)); ?>" class="btn btn-sm btn-outline-primary">Buka</a>
                            <form action="<?php echo e(route('admin.messages.destroy', $msg->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Hapus pesan ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-outline-danger">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center py-4 text-muted">Belum ada pesan masuk.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="card-footer bg-white">
        <?php echo e($messages->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/admin/messages/index.blade.php ENDPATH**/ ?>