

<?php $__env->startSection('page_title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-3">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-uppercase mb-1">Total Berita</h6>
                        <h2 class="mb-0"><?php echo e($stats['posts']); ?></h2>
                    </div>
                    <i class="fas fa-newspaper fa-3x opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-success text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-uppercase mb-1">Kategori</h6>
                        <h2 class="mb-0"><?php echo e($stats['categories']); ?></h2>
                    </div>
                    <i class="fas fa-folder fa-3x opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-info text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-uppercase mb-1">Halaman Statis</h6>
                        <h2 class="mb-0"><?php echo e($stats['pages']); ?></h2>
                    </div>
                    <i class="fas fa-file-alt fa-3x opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-warning text-dark">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-uppercase mb-1">Pengguna</h6>
                        <h2 class="mb-0"><?php echo e($stats['users']); ?></h2>
                    </div>
                    <i class="fas fa-users fa-3x opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-4 mb-4">
        <div class="card bg-indigo text-white h-100" style="background: #6610f2;">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-uppercase mb-1">Database Gugus Depan</h6>
                        <h2 class="mb-0"><?php echo e($stats['gudeps']); ?> Pangkalan</h2>
                    </div>
                    <i class="fas fa-university fa-3x opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-4">
        <div class="card bg-teal text-white h-100" style="background: #20c997;">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-uppercase mb-1">Total Anggota Terdata</h6>
                        <h2 class="mb-0"><?php echo e(number_format($stats['total_members'])); ?></h2>
                    </div>
                    <i class="fas fa-id-card fa-3x opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-4">
        <div class="card bg-success text-white h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-uppercase mb-1">Manajemen LPK</h6>
                        <h4 class="mb-0">LPK & Keuangan</h4>
                    </div>
                    <i class="fas fa-balance-scale fa-3x opacity-50"></i>
                </div>
                <div class="mt-3">
                    <a href="<?php echo e(route('admin.lpk.landingpage')); ?>" class="btn btn-sm btn-light">Kelola LPK</a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header bg-white">
                <h5 class="m-0 fw-bold">Selamat Datang di Panel Admin Kwarran Bekasi Timur</h5>
            </div>
            <div class="card-body">
                <p>Gunakan menu di sebelah kiri untuk mengelola konten website Anda. Anda dapat menambah berita baru, mengelola kategori, dan mengubah isi halaman statis.</p>
                <div class="d-flex gap-2">
                    <a href="<?php echo e(route('admin.posts.create')); ?>" class="btn btn-primary"><i class="fas fa-plus me-2"></i>Tulis Berita Baru</a>
                    <a href="<?php echo e(route('admin.posts.index')); ?>" class="btn btn-outline-primary"><i class="fas fa-list me-2"></i>Lihat Semua Berita</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>