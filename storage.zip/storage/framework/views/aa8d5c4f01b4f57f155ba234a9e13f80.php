

<?php $__env->startSection('page_title', 'Buat Album DKR'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-lg-10">
        <div class="card shadow-sm">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h5 class="m-0 fw-bold">Buat Album Galeri Baru</h5>
                <a href="<?php echo e(route('admin.dkr.albums.index')); ?>" class="btn btn-sm btn-outline-secondary">Kembali</a>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.dkr.albums.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    
                    <div class="row">
                        <div class="col-md-8">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Nama Album</label>
                                <input type="text" name="name" class="form-control" placeholder="Contoh: Sidang Paripurna Ranting 2025" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Deskripsi Singkat</label>
                                <textarea name="description" class="form-control" rows="2" placeholder="Keterangan mengenai album ini..."></textarea>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Foto Sampul (Cover)</label>
                                <input type="file" name="cover_image" class="form-control" accept="image/*">
                                <small class="text-muted">Foto utama yang muncul di depan.</small>
                            </div>
                        </div>
                    </div>

                    <hr class="my-4">

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h6 class="fw-bold m-0"><i class="fas fa-images me-1"></i> Upload Foto Album</h6>
                        <button type="button" class="btn btn-sm btn-outline-primary" onclick="addPhotoInput()">+ Tambah Foto</button>
                    </div>

                    <div id="photo-inputs-container">
                        <div class="row g-2 mb-3 photo-input-row border p-2 rounded bg-light" id="row-0">
                            <div class="col-md-5">
                                <input type="file" name="photos[]" class="form-control form-control-sm" accept="image/*" required>
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="captions[]" class="form-control form-control-sm" placeholder="Keterangan foto (opsional)">
                            </div>
                            <div class="col-md-1 text-end">
                                <button type="button" class="btn btn-sm btn-danger w-100" onclick="removeRow(0)"><i class="fas fa-times"></i></button>
                            </div>
                        </div>
                    </div>

                    <div class="alert alert-info small d-flex align-items-center gap-2">
                        <i class="fas fa-info-circle"></i>
                        Semua foto yang diupload akan otomatis dikompress oleh sistem untuk menjaga performa website.
                    </div>

                    <div class="d-grid mt-4">
                        <button type="submit" class="btn btn-primary btn-lg shadow-sm">SIMPAN ALBUM & FOTO</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    let rowCount = 1;
    function addPhotoInput() {
        const container = document.getElementById('photo-inputs-container');
        const html = `
            <div class="row g-2 mb-3 photo-input-row border p-2 rounded bg-light" id="row-${rowCount}">
                <div class="col-md-5">
                    <input type="file" name="photos[]" class="form-control form-control-sm" accept="image/*" required>
                </div>
                <div class="col-md-6">
                    <input type="text" name="captions[]" class="form-control form-control-sm" placeholder="Keterangan foto (opsional)">
                </div>
                <div class="col-md-1 text-end">
                    <button type="button" class="btn btn-sm btn-danger w-100" onclick="removeRow(${rowCount})"><i class="fas fa-times"></i></button>
                </div>
            </div>
        `;
        container.insertAdjacentHTML('beforeend', html);
        rowCount++;
    }

    function removeRow(id) {
        document.getElementById(`row-${id}`).remove();
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/admin/dkr/albums/create.blade.php ENDPATH**/ ?>