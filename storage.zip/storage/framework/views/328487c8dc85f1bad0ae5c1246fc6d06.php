

<?php $__env->startSection('page_title', 'Tambah User'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="m-0 fw-bold">Tambah User Baru</h5>
        <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-secondary btn-sm rounded-pill"><i class="fas fa-arrow-left me-1"></i> Kembali</a>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('admin.users.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            
            <div class="mb-3">
                <label class="form-label fw-bold">Nama Lengkap</label>
                <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name')); ?>" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3">
                <label class="form-label fw-bold">Email</label>
                <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" required>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Password</label>
                    <input type="password" name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <small class="text-muted">Minimal 8 karakter.</small>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Konfirmasi Password</label>
                    <input type="password" name="password_confirmation" class="form-control" required>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label fw-bold">Role Akses</label>
                <select name="role" class="form-select <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="roleSelect" required>
                    <option value="admin"          <?php echo e(old('role') == 'admin' ? 'selected' : ''); ?>>Admin (Semua Akses)</option>
                    <option value="humas"          <?php echo e(old('role') == 'humas' || !old('role') ? 'selected' : ''); ?>>Humas (Edit Konten, No Delete/Settings)</option>
                    <option value="lpk"            <?php echo e(old('role') == 'lpk' ? 'selected' : ''); ?>>LPK (Laporan Keuangan Sahaja)</option>
                    <option value="operator_gudep" <?php echo e(old('role') == 'operator_gudep' ? 'selected' : ''); ?>>🏫 Operator Gudep (Kelola Data Gudep Pangkalan)</option>
                    <option value="dkr"            <?php echo e(old('role') == 'dkr' ? 'selected' : ''); ?>>🚩 Operator DKR (Kelola Landing Page DKR)</option>
                </select>
                <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <small class="text-muted d-block mt-1">Pilih tingkat akses yang sesuai untuk user ini.</small>
            </div>

            
            <div id="gudepRoleInfo" class="alert alert-info d-flex gap-2 align-items-start mb-4 d-none">
                <i class="fas fa-university fa-lg mt-1"></i>
                <div>
                    <strong>Role: Operator Gudep</strong>
                    <p class="mb-0 small">User ini hanya dapat mengakses dan mengelola data <strong>Gudep & Pangkalan</strong>. Permission <em>gudep</em> akan diberikan secara otomatis.</p>
                </div>
            </div>

            <div id="dkrRoleInfo" class="alert alert-warning d-flex gap-2 align-items-start mb-4 d-none">
                <i class="fas fa-users-cog fa-lg mt-1"></i>
                <div>
                    <strong>Role: Operator DKR</strong>
                    <p class="mb-0 small">User ini hanya dapat mengakses dan mengelola <strong>Landing Page & Berita DKR</strong>. Permission <em>dkr</em> akan diberikan secara otomatis.</p>
                </div>
            </div>

            <div id="permissionsSection" class="mb-4 <?php echo e(in_array(old('role'), ['admin', 'operator_gudep']) ? 'd-none' : ''); ?>">
                <label class="form-label fw-bold d-block mb-3 border-bottom pb-2">Izin Akses Menu (Custom Permissions)</label>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <h6 class="small fw-bold text-primary">PUBLIKASI KONTEN</h6>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="permissions[]" value="posts" id="perm_posts" <?php echo e(in_array('posts', old('permissions', [])) ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="perm_posts">Kelola Berita & Materi Pokok</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="permissions[]" value="sliders" id="perm_sliders" <?php echo e(in_array('sliders', old('permissions', [])) ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="perm_sliders">Kelola Slider Beranda</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="permissions[]" value="events" id="perm_events" <?php echo e(in_array('events', old('permissions', [])) ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="perm_events">Kelola Agenda Kegiatan</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="permissions[]" value="gallery" id="perm_gallery" <?php echo e(in_array('gallery', old('permissions', [])) ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="perm_gallery">Kelola Galeri Foto/Video</label>
                        </div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <h6 class="small fw-bold text-primary">SISTEM INFORMASI (SISRAN)</h6>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="permissions[]" value="sisran" id="perm_sisran" <?php echo e(in_array('sisran', old('permissions', [])) ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="perm_sisran">Desain & Rekap Data SISRAN</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="permissions[]" value="finances" id="perm_finances" <?php echo e(in_array('finances', old('permissions', [])) ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="perm_finances">Kelola Keuangan (LPK)</label>
                        </div>
                    </div>

                    <div class="col-md-6 mb-3">
                        <h6 class="small fw-bold text-primary">PUSAT INFORMASI</h6>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="permissions[]" value="messages" id="perm_messages" <?php echo e(in_array('messages', old('permissions', [])) ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="perm_messages">Lihat Inbox Pesan</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="permissions[]" value="visitors" id="perm_visitors" <?php echo e(in_array('visitors', old('permissions', [])) ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="perm_visitors">Lihat Statistik Pengunjung</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="permissions[]" value="organization" id="perm_organization" <?php echo e(in_array('organization', old('permissions', [])) ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="perm_organization">Kelola Struktur Organisasi</label>
                        </div>
                    </div>

                    <div class="col-md-6 mb-3">
                        <h6 class="small fw-bold text-primary">FILE & DOKUMEN</h6>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="permissions[]" value="downloads" id="perm_downloads" <?php echo e(in_array('downloads', old('permissions', [])) ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="perm_downloads">Kelola Download Area</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="permissions[]" value="documents" id="perm_documents" <?php echo e(in_array('documents', old('permissions', [])) ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="perm_documents">Kelola Dokumen Publik</label>
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="alert alert-warning py-2 d-flex align-items-center gap-2 mt-2">
                            <i class="fas fa-university fa-lg"></i>
                            <div>
                                <h6 class="small fw-bold mb-0">DATABASE GUDEP & PANGKALAN</h6>
                                <div class="form-check mt-1">
                                    <input class="form-check-input" type="checkbox" name="permissions[]" value="gudep" id="perm_gudep" <?php echo e(in_array('gudep', old('permissions', [])) ? 'checked' : ''); ?>>
                                    <label class="form-check-label fw-bold" for="perm_gudep">Kelola Data Gudep & Pangkalan</label>
                                    <small class="d-block text-muted">User hanya bisa mengakses dan mengelola data Gudep/Pangkalan saja.</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php $__env->startPush('scripts'); ?>
            <script>
                function handleRoleChange(role) {
                    const section = document.getElementById('permissionsSection');
                    const gudepInfo = document.getElementById('gudepRoleInfo');
                    const dkrInfo = document.getElementById('dkrRoleInfo');
                    
                    if (role === 'admin') {
                        section.classList.add('d-none');
                        gudepInfo.classList.add('d-none');
                        dkrInfo.classList.add('d-none');
                    } else if (role === 'operator_gudep') {
                        section.classList.add('d-none');
                        gudepInfo.classList.remove('d-none');
                        dkrInfo.classList.add('d-none');
                    } else if (role === 'dkr') {
                        section.classList.add('d-none');
                        gudepInfo.classList.add('d-none');
                        dkrInfo.classList.remove('d-none');
                    } else {
                        section.classList.remove('d-none');
                        gudepInfo.classList.add('d-none');
                        dkrInfo.classList.add('d-none');
                    }
                }

                document.getElementById('roleSelect').addEventListener('change', function() {
                    handleRoleChange(this.value);
                });

                // Run on page load
                handleRoleChange(document.getElementById('roleSelect').value);
            </script>
            <?php $__env->stopPush(); ?>

            <div class="d-grid mt-4">
                <button type="submit" class="btn btn-primary rounded-pill">Simpan User</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/admin/users/create.blade.php ENDPATH**/ ?>