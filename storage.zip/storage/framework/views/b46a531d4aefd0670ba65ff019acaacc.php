

<?php $__env->startSection('page_title', 'Pengaturan Grafik: ' . $sisran_form->title); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <a href="<?php echo e(route('admin.sisran.visualize.index')); ?>" class="btn btn-light rounded-pill px-4 shadow-sm border">
        <i class="fas fa-arrow-left me-2"></i>Kembali
    </a>
</div>

<div class="card border-0 shadow-sm rounded-4">
    <div class="card-header bg-white p-4 border-0">
        <h5 class="fw-bold m-0"><i class="fas fa-eye me-2 text-primary"></i>Konfigurasi Tampilan Data</h5>
    </div>
    <div class="card-body p-4">
        <?php if(session('success')): ?>
            <div class="alert alert-success border-0 rounded-3 mb-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('admin.sisran.visualize.update', $sisran_form)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <table class="table align-middle">
                <thead class="bg-light">
                    <tr>
                        <th class="ps-3">Nama Kolom (Label)</th>
                        <th>Tipe Data</th>
                        <th width="300">Jenis Visualisasi Chart</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sisran_form->fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(in_array($field->type, ['number', 'select', 'radio', 'checkbox'])): ?>
                    <tr>
                        <td class="ps-3 fw-bold"><?php echo e($field->label); ?></td>
                        <td>
                            <span class="badge bg-secondary bg-opacity-10 text-secondary"><?php echo e(ucfirst($field->type)); ?></span>
                        </td>
                        <td>
                            <select name="fields[<?php echo e($field->id); ?>]" class="form-select rounded-pill">
                                <option value="bar" <?php echo e($field->chart_type == 'bar' ? 'selected' : ''); ?>>Grafik Batang (Bar)</option>
                                <option value="pie" <?php echo e($field->chart_type == 'pie' ? 'selected' : ''); ?>>Grafik Lingkaran (Pie)</option>
                                <option value="doughnut" <?php echo e($field->chart_type == 'doughnut' ? 'selected' : ''); ?>>Grafik Donat (Doughnut)</option>
                                <option value="line" <?php echo e($field->chart_type == 'line' ? 'selected' : ''); ?>>Grafik Garis (Line)</option>
                            </select>
                        </td>
                    </tr>
                    <?php else: ?>
                    <tr class="opacity-50">
                        <td class="ps-3"><?php echo e($field->label); ?></td>
                        <td><span class="badge bg-light text-muted"><?php echo e(ucfirst($field->type)); ?></span></td>
                        <td class="small italic text-muted">Tipe teks tidak dapat dijadikan grafik</td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <div class="text-end mt-4">
                <button type="submit" class="btn btn-primary rounded-pill px-5 shadow-sm">
                    Simpan Pengaturan Visualisasi
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/admin/sisran/visualize_show.blade.php ENDPATH**/ ?>