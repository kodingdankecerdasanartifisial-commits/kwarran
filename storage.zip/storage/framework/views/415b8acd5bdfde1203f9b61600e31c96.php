

<?php $__env->startSection('page_title', 'Berita / Posts LPK'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="m-0 fw-bold">Daftar Berita LPK</h5>
        <a href="<?php echo e(route('admin.posts.create', ['category_id' => $category?->id])); ?>" class="btn btn-primary btn-sm">
            <i class="fas fa-plus me-1"></i> Buat Berita LPK
        </a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="bg-light">
                    <tr>
                        <th width="100">Gambar</th>
                        <th>Judul Berita</th>
                        <th>Status</th>
                        <th>Tanggal Publish</th>
                        <th class="text-end">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <?php if($post->featured_image): ?>
                                <img src="<?php echo e(asset('storage/' . $post->featured_image)); ?>" class="rounded shadow-sm" style="width: 80px; height: 50px; object-fit: cover;">
                            <?php else: ?>
                                <div class="bg-light rounded text-center" style="width: 80px; height: 50px; line-height: 50px;">
                                    <i class="fas fa-image text-muted opacity-50"></i>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="fw-bold"><?php echo e($post->title); ?></div>
                            <small class="text-muted"><i class="fas fa-eye me-1"></i> <?php echo e($post->views); ?> tayangan</small>
                        </td>
                        <td>
                            <?php if($post->is_published): ?>
                                <span class="badge bg-success">Published</span>
                            <?php else: ?>
                                <span class="badge bg-warning text-dark">Draft</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php echo e($post->published_at ? $post->published_at->format('d/m/Y') : '-'); ?><br>
                            <small class="text-muted"><?php echo e($post->published_at ? $post->published_at->format('H:i') : ''); ?></small>
                        </td>
                        <td class="text-end">
                            <div class="btn-group">
                                <a href="<?php echo e(route('posts.show', $post->slug)); ?>" target="_blank" class="btn btn-sm btn-outline-info" title="Lihat">
                                    <i class="fas fa-external-link-alt"></i>
                                </a>
                                <a href="<?php echo e(route('admin.posts.edit', $post->id)); ?>" class="btn btn-sm btn-outline-primary" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('admin.posts.destroy', $post->id)); ?>" method="POST" onsubmit="return confirm('Hapus berita ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Hapus">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center py-5 text-muted">
                            <i class="fas fa-newspaper fa-3x mb-3 opacity-25"></i>
                            <p>Belum ada berita khusus LPK.</p>
                            <a href="<?php echo e(route('admin.posts.create', ['category_id' => $category?->id])); ?>" class="btn btn-primary btn-sm">Mulai Menulis</a>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="mt-4">
            <?php echo e($posts->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/admin/lpk/posts.blade.php ENDPATH**/ ?>