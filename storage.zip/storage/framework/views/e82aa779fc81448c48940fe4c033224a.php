<img src="<?php echo e(asset('logo.png')); ?>" <?php echo e($attributes); ?>>
<?php /**PATH D:\xampp\htdocs\kwarran\resources\views/components/application-logo.blade.php ENDPATH**/ ?>