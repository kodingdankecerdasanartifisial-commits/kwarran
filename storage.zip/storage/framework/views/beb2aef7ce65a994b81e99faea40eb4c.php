

<?php $__env->startSection('page_title', 'Edit Galeri'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-header bg-white p-4">
                <h5 class="m-0 fw-bold">Edit Item Galeri</h5>
            </div>
            <div class="card-body p-4">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <form action="<?php echo e(route('admin.gallery.update', $gallery->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <div class="mb-4">
                        <label class="form-label fw-bold">Tipe Galeri</label>
                        <div class="d-flex gap-3">
                            <div class="form-check custom-option">
                                <input class="form-check-input" type="radio" name="type" id="typePhoto" value="photo" <?php echo e($gallery->type === 'photo' ? 'checked' : 'disabled'); ?>>
                                <label class="form-check-label" for="typePhoto">
                                    <i class="fas fa-camera me-1"></i> Foto
                                </label>
                            </div>
                            <div class="form-check custom-option">
                                <input class="form-check-input" type="radio" name="type" id="typeVideo" value="video" <?php echo e($gallery->type === 'video' ? 'checked' : 'disabled'); ?>>
                                <label class="form-check-label" for="typeVideo">
                                    <i class="fas fa-video me-1"></i> Video YouTube
                                </label>
                            </div>
                        </div>
                        <small class="text-muted">Tipe tidak dapat diubah setelah dibuat.</small>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Judul/Nama Kegiatan</label>
                        <input type="text" name="title" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('title', $gallery->title)); ?>" required>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <?php if($gallery->type === 'photo'): ?>
                        <div id="photoFields">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Link Google Drive / Album Eksternal (Opsional)</label>
                                <input type="url" name="external_link" class="form-control <?php $__errorArgs = ['external_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('external_link', $gallery->external_link)); ?>" placeholder="https://photos.google.com/share/...">
                                <small class="text-muted">Gunakan ini jika foto disimpan di luar server (Google Drive/Photos).</small>
                                <?php $__errorArgs = ['external_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-bold">Upload Foto / Cover</label>
                                <?php if($gallery->image): ?>
                                    <div class="mb-2">
                                        <p class="small mb-1 text-muted">Cover Saat Ini:</p>
                                        <img src="<?php echo e(asset('storage/' . $gallery->image)); ?>" alt="Current Image" class="img-thumbnail" style="max-height: 150px;">
                                    </div>
                                <?php endif; ?>
                                <input type="file" name="image" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept="image/*">
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <small class="text-muted">
                                    <?php if($gallery->external_link): ?>
                                        Unggah foto untuk dijadikan sampul (thumbnail) di halaman utama.
                                    <?php else: ?>
                                        Unggah file foto jika tidak menggunakan link eksternal.
                                    <?php endif; ?>
                                    (Biarkan kosong jika tidak ingin mengubah)
                                </small>
                            </div>
                        </div>
                    <?php else: ?>
                        <div id="videoFields">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Link YouTube / ID Video</label>
                                <input type="text" name="external_link" class="form-control <?php $__errorArgs = ['external_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('external_link', 'https://www.youtube.com/watch?v=' . $gallery->external_link)); ?>" placeholder="Contoh: https://www.youtube.com/watch?v=xxxxxx">
                                <?php $__errorArgs = ['external_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <small class="text-muted">Masukkan URL lengkap atau cukup ID videonya saja.</small>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="mb-4">
                        <label class="form-label fw-bold">Keterangan (Opsional)</label>
                        <textarea name="description" class="form-control" rows="3"><?php echo e(old('description', $gallery->description)); ?></textarea>
                    </div>

                    <div class="d-flex justify-content-between pt-3 border-top">
                        <a href="<?php echo e(route('admin.gallery.index')); ?>" class="btn btn-secondary rounded-pill px-4">Batal</a>
                        <button type="submit" class="btn btn-primary rounded-pill px-4">Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/admin/gallery/edit.blade.php ENDPATH**/ ?>