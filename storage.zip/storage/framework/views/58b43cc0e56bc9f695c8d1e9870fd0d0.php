

<?php $__env->startSection('page_title', 'Manajemen Galeri'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="m-0 fw-bold">Daftar Galeri</h5>
        <a href="<?php echo e(route('admin.gallery.create')); ?>" class="btn btn-primary btn-sm rounded-pill">
            <i class="fas fa-plus me-1"></i> Tambah Galeri Baru
        </a>
    </div>
    <div class="card-body">
        <div class="row g-4">
            <?php $__empty_1 = true; $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-3">
                <div class="card h-100 border-0 shadow-sm rounded-3 overflow-hidden">
                    <div class="position-relative">
                        <?php if($item->type === 'photo'): ?>
                            <img src="<?php echo e($item->image ? asset('storage/' . $item->image) : asset('img/drive-placeholder.png')); ?>" class="card-img-top object-fit-cover" style="height: 180px;">
                            <span class="position-absolute top-0 start-0 m-2 badge bg-primary">Foto</span>
                        <?php else: ?>
                            <img src="https://img.youtube.com/vi/<?php echo e($item->external_link); ?>/0.jpg" class="card-img-top object-fit-cover" style="height: 180px;">
                            <span class="position-absolute top-0 start-0 m-2 badge bg-danger">Video</span>
                        <?php endif; ?>
                    </div>
                    <div class="card-body p-3">
                        <h6 class="fw-bold mb-1 text-truncate"><?php echo e($item->title); ?></h6>
                        <p class="small text-muted mb-3"><?php echo e(Str::limit($item->description, 50)); ?></p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="small text-muted"><?php echo e($item->created_at->format('d M y')); ?></span>
                            <div class="btn-group">
                                <a href="<?php echo e(route('admin.gallery.edit', $item->id)); ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i></a>
                                <?php if(auth()->user()->role === 'admin'): ?>
                                <form action="<?php echo e(route('admin.gallery.destroy', $item->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Hapus item ini?')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                                </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12 text-center py-5">
                <p class="text-muted">Belum ada koleksi galeri.</p>
            </div>
            <?php endif; ?>
        </div>
        <div class="mt-4">
            <?php echo e($galleries->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/admin/gallery/index.blade.php ENDPATH**/ ?>