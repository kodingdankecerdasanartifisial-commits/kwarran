

<?php $__env->startSection('title', 'Beranda - Kwarran Bekasi Timur'); ?>

<?php $__env->startSection('content'); ?>
<!-- Hero Slideshow -->
<section class="hero-slider-section pt-1">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="swiper main-slider shadow-sm overflow-hidden">
                    <div class="swiper-wrapper">
                        <?php $__empty_1 = true; $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="swiper-slide">
                            <div class="slider-bg" style="background-image: linear-gradient(rgba(0,0,0,0.2), rgba(0,0,0,0.5)), url('<?php echo e(asset('storage/' . $slider->image)); ?>');"></div>
                            <div class="container h-100">
                                <div class="row h-100 align-items-center">
                                    <div class="col-lg-8 ps-md-5 text-start animate__animated animate__fadeInUp">
                                        <?php if($slider->title): ?>
                                            <h2 class="display-5 fw-bold text-white mb-2"><?php echo e($slider->title); ?></h2>
                                        <?php endif; ?>
                                        <?php if($slider->subtitle): ?>
                                            <p class="lead text-white mb-4 fs-5 d-none d-md-block"><?php echo e($slider->subtitle); ?></p>
                                        <?php endif; ?>
                                        <?php if($slider->link): ?>
                                            <a href="<?php echo e($slider->link); ?>" class="btn btn-warning fw-bold shadow-sm">
                                                SELENGKAPNYA <i class="fas fa-arrow-right ms-2"></i>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="swiper-slide">
                            <div class="slider-bg" style="background-image: linear-gradient(rgba(0,0,0,0.2), rgba(0,0,0,0.5)), url('https://images.unsplash.com/photo-1523240795612-9a054b0db644?q=80&w=1920&auto=format&fit=crop');"></div>
                            <div class="container h-100 text-center">
                                <div class="row h-100 align-items-center justify-content-center">
                                    <div class="col-lg-10">
                                        <h2 class="display-5 fw-bold text-white mb-2">Kwarran Bekasi Timur</h2>
                                        <p class="lead text-white mb-4 fs-5 d-none d-md-block">Membangun Karakter Bangsa melalui Gerakan Pramuka yang Inovatif.</p>
                                        <div class="d-flex gap-3 justify-content-center">
                                            <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-warning fw-bold">Warta Pramuka</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <!-- Add Pagination -->
                    <div class="swiper-pagination"></div>
                    <!-- Add Navigation -->
                    <div class="swiper-button-next d-none d-md-flex"></div>
                    <div class="swiper-button-prev d-none d-md-flex"></div>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
    .hero-slider-section {
        background-color: #f8f9fa;
    }
    .main-slider {
        height: 550px; /* Adjusted height */
        width: 100%;
        position: relative;
        border-radius: 5px; /* Adjusted curvature */
    }
    .slider-bg {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-size: cover;
        background-position: center;
        z-index: -1;
        transition: transform 8s ease;
    }
    .swiper-slide-active .slider-bg {
        transform: scale(1.15);
    }
    .swiper-button-next, .swiper-button-prev {
        color: white;
        background: rgba(0,0,0,0.2);
        width: 40px;
        height: 40px;
        border-radius: 50%;
    }
    .swiper-button-next:after, .swiper-button-prev:after {
        font-size: 16px;
    }
    .swiper-pagination-bullet {
        background: white;
        opacity: 0.6;
    }
    .swiper-pagination-bullet-active {
        opacity: 1;
        background: var(--secondary-color);
    }
    
    @media (max-width: 768px) {
        .main-slider { height: 280px; border-radius: 5px; }
        .display-5 { font-size: 1.8rem; }
    }
</style>

<!-- Newsflash Section -->
<div class="newsflash-section py-1 bg-white text-dark mb-4 shadow-sm">
    <div class="container">
        <div class="row align-items-center g-0">
            <div class="col-auto">
                <div class="newsflash-label px-3 py-2 fw-bold text-uppercase small me-3 position-relative" style="background-color: var(--accent-color, #f39c12); color: #f7f0f0;">
                    <i class="fas fa-bullhorn me-2"></i> INFO TERBARU
                </div>
            </div>
            <div class="col overflow-hidden">
                <div class="newsflash-wrapper">
                    <marquee direction="down" height="25" onmouseover="this.stop();" onmouseout="this.start();" scrollamount="2" style="line-height: 25px;">
                        <?php $__currentLoopData = $latestPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('posts.show', $post->slug)); ?>" class="text-decoration-none text-dark d-block small fw-medium hover-opacity">
                                <span class="badge bg-secondary me-2" style="font-size: 0.7rem;"><?php echo e($post->published_at?->format('d/m')); ?></span> <?php echo e($post->title); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </marquee>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .newsflash-section {
        position: relative;
        z-index: 10;
        margin-top: 0;
    }
    .hover-opacity:hover {
        opacity: 0.8;
    }
    .newsflash-label {
        clip-path: polygon(0 0, 100% 0, 95% 100%, 0% 100%);
        padding-right: 1.5rem !important;
    }

    /* Digital Banner Styling */
    .digital-banner-section .banner-wrapper {
        width: 100%;
        overflow: hidden;
    }
    .digital-banner-section .banner-img {
        width: 100%;
        height: auto;
        display: block;
    }
</style>

<!-- Digital Banner Section -->
<?php if($digitalBanners->count() > 0): ?>
<section class="digital-banner-section mb-4">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <?php $__currentLoopData = $digitalBanners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="banner-wrapper shadow-sm mb-3">
                    <?php if($banner->link): ?>
                        <a href="<?php echo e($banner->link); ?>" target="_blank">
                            <img src="<?php echo e(asset('storage/' . $banner->image)); ?>" alt="<?php echo e($banner->title); ?>" class="banner-img">
                        </a>
                    <?php else: ?>
                        <img src="<?php echo e(asset('storage/' . $banner->image)); ?>" alt="<?php echo e($banner->title); ?>" class="banner-img">
                    <?php endif; ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<div class="container my-5">
    <div class="row">
        <!-- Main Content Column (left) -->
        <div class="col-lg-8">
            <!-- Top Section: Featured & Stacked News -->
            <div class="row">
                <!-- Kolom 1: Cuplikan Berita Utama (Featured) -->
                <div class="col-lg-7 mb-4">
                    <h4 class="fw-bold mb-3 border-start border-4 border-warning ps-3">UTAMA</h4>
                    <?php if($mainPost): ?>
                    <div class="card border-0 shadow-sm rounded-4 overflow-hidden h-100">
                        <div class="position-relative">
                            <?php
                                $mainThumbnail = null;
                                if ($mainPost->featured_image) {
                                    $mainThumbnail = asset('storage/' . $mainPost->featured_image);
                                } elseif ($mainPost->youtube_url) {
                                    preg_match('/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/', $mainPost->youtube_url, $matches);
                                    if (isset($matches[1])) {
                                        $mainThumbnail = "https://img.youtube.com/vi/{$matches[1]}/mqdefault.jpg";
                                    }
                                }
                            ?>

                            <?php if($mainThumbnail): ?>
                                <img src="<?php echo e($mainThumbnail); ?>" class="card-img-top" style="height: 350px; object-fit: cover;" alt="<?php echo e($mainPost->title); ?>">
                                <?php if(!$mainPost->featured_image && $mainPost->youtube_url): ?>
                                <div class="position-absolute top-50 start-50 translate-middle">
                                    <i class="fab fa-youtube fa-4x text-danger bg-white rounded-circle p-1"></i>
                                </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="bg-light d-flex align-items-center justify-content-center" style="height: 350px;">
                                    <i class="fas fa-image fa-3x text-secondary opacity-25"></i>
                                </div>
                            <?php endif; ?>
                            <?php if($mainPost->category): ?>
                            <div class="position-absolute top-0 start-0 m-3">
                                <span class="badge bg-warning text-dark px-3 py-2 fw-bold shadow-sm"><?php echo e($mainPost->category->name); ?></span>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="card-body p-4">
                            <div class="d-flex align-items-center text-muted small mb-2">
                                <i class="far fa-calendar-alt me-2"></i> <?php echo e($mainPost->published_at?->format('d M Y')); ?>

                                <span class="mx-2">|</span>
                                <i class="far fa-user me-2"></i> <?php echo e($mainPost->author); ?>

                            </div>
                            <h3 class="card-title fw-bold mb-3">
                                <a href="<?php echo e(route('posts.show', $mainPost->slug)); ?>" class="text-decoration-none text-dark hover-primary"><?php echo e($mainPost->title); ?></a>
                            </h3>
                            <p class="card-text text-muted mb-4"><?php echo e($mainPost->excerpt ?? Str::limit(strip_tags($mainPost->content), 150)); ?></p>
                            <a href="<?php echo e(route('posts.show', $mainPost->slug)); ?>" class="btn btn-outline-warning fw-bold px-4 rounded-pill">BACA SELENGKAPNYA</a>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Kolom 2: Berita Bertumpuk (Recent List) -->
                <div class="col-lg-5 mb-4">
                    <h4 class="fw-bold mb-3 border-start border-4 border-warning ps-3">BERITA TERBARU</h4>
                    <div class="stacked-news">
                        <?php $__empty_1 = true; $__currentLoopData = $stackedPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="card border-0 shadow-sm rounded-4 mb-3 overflow-hidden">
                            <div class="row g-0">
                                <div class="col-4">
                                    <?php
                                        $stackedThumbnail = null;
                                        if ($post->featured_image) {
                                            $stackedThumbnail = asset('storage/' . $post->featured_image);
                                        } elseif ($post->youtube_url) {
                                            preg_match('/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/', $post->youtube_url, $matches);
                                            if (isset($matches[1])) {
                                                $stackedThumbnail = "https://img.youtube.com/vi/{$matches[1]}/mqdefault.jpg";
                                            }
                                        }
                                    ?>

                                    <?php if($stackedThumbnail): ?>
                                        <div class="position-relative h-100">
                                            <img src="<?php echo e($stackedThumbnail); ?>" class="img-fluid h-100 w-100" style="object-fit: cover; min-height: 100px;" alt="<?php echo e($post->title); ?>">
                                            <?php if(!$post->featured_image && $post->youtube_url): ?>
                                            <div class="position-absolute top-50 start-50 translate-middle">
                                                <i class="fab fa-youtube fa-2x text-danger bg-white rounded-circle p-1"></i>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php else: ?>
                                        <div class="bg-light d-flex align-items-center justify-content-center h-100" style="min-height: 100px;">
                                            <i class="fas fa-image text-secondary opacity-25"></i>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="col-8">
                                    <div class="card-body p-3">
                                        <small class="text-muted d-block mb-1"><?php echo e($post->published_at?->format('d M Y')); ?></small>
                                        <h6 class="card-title fw-bold mb-0">
                                            <a href="<?php echo e(route('posts.show', $post->slug)); ?>" class="text-decoration-none text-dark hover-primary small" style="line-height: 1.4;"><?php echo e(Str::limit($post->title, 60)); ?></a>
                                        </h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-muted">Belum ada berita terbaru lainnya.</p>
                        <?php endif; ?>
                        <div class="text-center mt-4">
                            <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-warning w-100 fw-bold rounded-pill shadow-sm">LIHAT SEMUA BERITA</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Berita Per Kategori (Now inside Left Column) -->
            <?php if($categorySections->count() > 0): ?>
            <div class="category-news-sections mt-4 border-top pt-4">
                <?php $__currentLoopData = $categorySections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="category-block mb-5">
                    <div class="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom border-warning border-opacity-25">
                        <h3 class="fw-bold text-uppercase m-0" style="letter-spacing: 1px; font-size: 1.25rem;">
                            <span class="border-start border-4 border-warning ps-3"><?php echo e($section->name); ?></span>
                        </h3>
                        <a href="<?php echo e(route('categories.show', $section->slug)); ?>" class="btn btn-sm btn-link text-warning text-decoration-none fw-bold">SELENGKAPNYA <i class="fas fa-arrow-right ms-1"></i></a>
                    </div>
                    
                    <div class="row">
                        <?php $__currentLoopData = $section->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6 mb-4">
                            <div class="card h-100 border-0 shadow-sm rounded-4 overflow-hidden post-card-hover">
                                <div class="position-relative">
                                    <?php
                                        $catThumbnail = null;
                                        if ($post->featured_image) {
                                            $catThumbnail = asset('storage/' . $post->featured_image);
                                        } elseif ($post->youtube_url) {
                                            preg_match('/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/', $post->youtube_url, $matches);
                                            if (isset($matches[1])) {
                                                $catThumbnail = "https://img.youtube.com/vi/{$matches[1]}/mqdefault.jpg";
                                            }
                                        }
                                    ?>

                                    <?php if($catThumbnail): ?>
                                        <img src="<?php echo e($catThumbnail); ?>" class="card-img-top" style="height: 160px; object-fit: cover;" alt="<?php echo e($post->title); ?>">
                                        <?php if(!$post->featured_image && $post->youtube_url): ?>
                                        <div class="position-absolute top-50 start-50 translate-middle">
                                            <i class="fab fa-youtube fa-2x text-danger bg-white rounded-circle p-1"></i>
                                        </div>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <div class="bg-light d-flex align-items-center justify-content-center" style="height: 160px;">
                                            <i class="fas fa-image fa-2x text-secondary opacity-25"></i>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="card-body p-3">
                                    <small class="text-muted d-block mb-2"><i class="far fa-calendar-alt me-1"></i> <?php echo e($post->published_at?->format('d M Y')); ?></small>
                                    <h6 class="fw-bold mb-0" style="font-size: 0.95rem; line-height: 1.4;">
                                        <a href="<?php echo e(route('posts.show', $post->slug)); ?>" class="text-decoration-none text-dark hover-primary"><?php echo e(Str::limit($post->title, 55)); ?></a>
                                    </h6>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- Right Sidebar -->
        <div class="col-lg-4 d-none d-lg-block">
            <?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/home.blade.php ENDPATH**/ ?>