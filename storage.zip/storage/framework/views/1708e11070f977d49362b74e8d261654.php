

<?php $__env->startSection('page_title', 'Manajemen Statistik'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="m-0 fw-bold text-primary">Daftar Statistik Publik</h5>
        <a href="<?php echo e(route('admin.statistics.create')); ?>" class="btn btn-primary btn-sm rounded-pill">
            <i class="fas fa-plus me-1"></i> Buat Statistik Baru
        </a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="bg-light">
                    <tr>
                        <th width="5%">#</th>
                        <th>Judul Statistik</th>
                        <th>Deskripsi</th>
                        <th>Status</th>
                        <th>Dibuat</th>
                        <th width="20%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $statistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td>
                            <div class="fw-bold"><?php echo e($item->title); ?></div>
                            <small class="text-muted">Slug: <?php echo e($item->slug); ?></small>
                        </td>
                        <td><?php echo e(\Illuminate\Support\Str::limit($item->description, 50)); ?></td>
                        <td>
                            <?php if($item->is_published): ?>
                                <span class="badge bg-success rounded-pill">Publik</span>
                            <?php else: ?>
                                <span class="badge bg-secondary rounded-pill">Draft</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($item->created_at->format('d M Y')); ?></td>
                        <td>
                            <div class="btn-group">
                                <a href="<?php echo e(route('statistics.public.show', $item->slug)); ?>" target="_blank" class="btn btn-sm btn-outline-info" title="Lihat Publik">
                                    <i class="fas fa-external-link-alt"></i>
                                </a>
                                <a href="<?php echo e(route('admin.statistics.edit', $item->id)); ?>" class="btn btn-sm btn-outline-primary" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('admin.statistics.destroy', $item->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Hapus statistik ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-outline-danger" title="Hapus">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-5 text-muted">
                            <i class="fas fa-chart-line fa-3x mb-3 d-block opacity-25"></i>
                            Belum ada data statistik yang dibuat.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="mt-4 text-center">
    <a href="<?php echo e(route('statistics.public.index')); ?>" target="_blank" class="btn btn-outline-secondary rounded-pill">
        <i class="fas fa-th-list me-1"></i> Lihat Semua Indeks Statistik Publik
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kwarran\resources\views/admin/statistics/index.blade.php ENDPATH**/ ?>